<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsBlog extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-blog';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Blog Area', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'blog' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_Blog',

			[

				'label' => esc_html__( 'Blog', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'blog_type_1' => esc_html__( 'Blog Type 1', 'bdevs-elementor' ),

					'blog_type_2' => esc_html__( 'Blog Type 2', 'bdevs-elementor' ),

				],

				'default'   => 'blog_type_1',

			]

		);



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'sub_heading',

			[

				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'link',

			[

				'label'       => __( 'Link', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your Link', 'bdevs-elementor' ),

				'default'     => __( 'It is Link', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);





		$this->add_control(

			'button',

			[

				'label'       => __( 'Button', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your Button', 'bdevs-elementor' ),

				'default'     => __( 'It is Button', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'post_number',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'3'  => esc_html__( '3', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'9' => esc_html__( '9', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

				],

				'default'   => '3',

			]

		);



		$this->add_control(

			'post_order',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);





		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_blog_2',

			[

				'label' => esc_html__( 'Blog 2', 'bdevs-elementor' ),

			]

		);





		$this->add_control(

			'heading_type_2',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'sub_heading_type_2',

			[

				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'link_type_2',

			[

				'label'       => __( 'Link', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your Link', 'bdevs-elementor' ),

				'default'     => __( 'It is Link', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);





		$this->add_control(

			'button_type_2',

			[

				'label'       => __( 'Button', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your Button', 'bdevs-elementor' ),

				'default'     => __( 'It is Button', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'post_number2',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'3'  => esc_html__( '3', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'9' => esc_html__( '9', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

				],

				'default'   => '3',

			]

		);



		$this->add_control(

			'post_order2',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);





		$this->end_controls_section();







		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);	



		$this->add_control(

			'show_sub_heading',

			[

				'label'   => esc_html__( 'Show Sub Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);	



		$this->add_control(

			'show_image',

			[

				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->add_control(

			'show_content',

			[

				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



		



		$this->start_controls_section(

			'section_content_button',

			[

				'label'     => esc_html__( 'Button', 'bdevs-elementor' ),

				'condition' => [

					'show_button' => 'yes',

				],

			]

		);



		$this->add_control(

			'button_text',

			[

				'label'       => esc_html__( 'Button Text', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'default'     => esc_html__( 'Read More', 'bdevs-elementor' ),

				'placeholder' => esc_html__( 'Read More', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'icon',

			[

				'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

				'type'        => Controls_Manager::ICON,

				'label_block' => true,

			]

		);



		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		$chose_style = $settings['chose_style'];

		$order = $settings['post_order'];

		$post_number = $settings['post_number'];

		$order2 = $settings['post_order2'];

		$post_number2 = $settings['post_number2'];

		?>
		<h2 style="display: none;">1111111111</h2>
		<?php if( $chose_style == 'blog_type_1' ): ?>

		

		<section class="pdt-105 pdb-85 pdb-lg-75 pdb-md-83 blog-section1">

		<div class="section-title mrb-30 mrb-md-60">

			<div class="container">

				<div class="row">

					<div class="col-lg-8 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">

						<?php if (( '' !== $settings['sub_heading'] ) && ( $settings['show_sub_heading'] )): ?>

						<h5 class="text-primary-color text-underline mrb-15"><?php echo wp_kses_post($settings['sub_heading']); ?></h5>

						<?php endif; ?>

						<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>

						<h2 class="mrb-30"><?php echo wp_kses_post($settings['heading']); ?></h2>

						<?php endif; ?>

					</div>

					<div class="col-lg-4 col-xl-6 align-self-center text-left text-lg-right">

						<?php if (( '' !== $settings['button'] ) && ( $settings['show_button'] )): ?>

						<a href="<?php echo wp_kses_post($settings['link']); ?>" class="cs-btn-one btn-primary-color btn-md"><?php echo wp_kses_post($settings['button']); ?></a>

						<?php endif; ?>

					</div>

				</div>

			</div>

		</div>

		<div class="section-content">

			<div class="container">

				<div class="row">

					<?php 



					$args = new \WP_Query(array(   



						'post_type' => 'post', 



						'posts_per_page'=> $post_number,



						'order'         => $order,



					));  



					if($args->have_posts()):



						while ($args -> have_posts()) : $args -> the_post();   



							$home_image = get_post_meta(get_the_ID(),'_cmb_home_image', true);

							$home_title = get_post_meta(get_the_ID(),'_cmb_home_title', true);

							?> 

							<div class="col-md-6 col-lg-4 col-xl-4">

								<div class="news-wrapper mrb-30 mrb-sm-40">

									<div class="news-thumb">

										<img class="img-full" src="<?php echo esc_url($home_image);?>" alt="">

									</div>

									<div class="news-details pdt-25">

										<div class="news-description mb-20">

											<div class="news-bottom-meta mrb-15">

												<span class="entry-author mrr-20"><i class="far fa-user mrr-10 text-primary-color"></i><?php the_author_posts_link(); ?></span>

												<span class="entry-date"><i class="far fa-calendar-alt mrr-10 text-primary-color"></i><?php the_time(get_option( 'date_format'));?></span>

											</div>

											<h4 class="the-title mrb-20"><a href="<?php the_permalink();?>"><?php echo esc_attr($home_title); ?></a></h4>

											<p class="the-content"><?php if(isset($avitore_redux_demo['blog_excerpt'])){?>

												<?php echo esc_attr(avitore_excerpt3($avitore_redux_demo['blog_excerpt'])); ?>

											<?php }else{?>

												<?php echo esc_attr(avitore_excerpt3(15)); }?></p>

											</div>

											<div class="news-link">

												<a href="<?php the_permalink();?>"><?php if(isset($avitore_redux_demo['read_more'])){?>

													<?php echo htmlspecialchars_decode(esc_attr($avitore_redux_demo['read_more']));?>

												<?php }else{?>

													<?php echo esc_html__( 'Read more', 'avitore' ); }?> <i class="fa fa-angle-right mrl-5"></i></a>

												</div>

											</div>

										</div>

									</div>

									<?php 

								endwhile;  

								wp_reset_postdata();

							endif; 

							?>

						</div>

					</div>

				</div>

			</section>



		<?php elseif( $chose_style == 'blog_type_2' ): ?>

			<section class="bg-light-blue pdt-105 pdb-85 pdb-lg-75 pdb-md-83 blog-section1">

		<div class="section-title mrb-30 mrb-md-60">

			<div class="container">

				<div class="row">

					<div class="col-lg-8 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">

						<?php if (( '' !== $settings['sub_heading_type_2'] ) && ( $settings['show_sub_heading'] )): ?>

						<h5 class="text-primary-color text-underline mrb-15"><?php echo wp_kses_post($settings['sub_heading_type_2']); ?></h5>

						<?php endif; ?>

						<?php if (( '' !== $settings['heading_type_2'] ) && ( $settings['show_heading'] )): ?>

						<h2 class="mrb-30"><?php echo wp_kses_post($settings['heading_type_2']); ?></h2>

						<?php endif; ?>

					</div>

					<div class="col-lg-4 col-xl-6 align-self-center text-left text-lg-right">

						<?php if (( '' !== $settings['button_type_2'] ) && ( $settings['show_button'] )): ?>

						<a href="<?php echo wp_kses_post($settings['link_type_2']); ?>" class="cs-btn-one btn-primary-color4 btn-md"><?php echo wp_kses_post($settings['button_type_2']); ?></a>

						<?php endif; ?>

					</div>

				</div>

			</div>

		</div>

		<div class="section-content">

			<div class="container">

				<div class="row">

					<?php 



					$args = new \WP_Query(array(   



						'post_type' => 'post', 



						'posts_per_page'=> $post_number2,



						'order'         => $order2,



					));  



					if($args->have_posts()):


					while ($args -> have_posts()) : $args -> the_post();   


					$home_image = get_post_meta(get_the_ID(),'_cmb_home_image', true);

					$home_title = get_post_meta(get_the_ID(),'_cmb_home_title', true);

					?> 

					<div class="col-md-6 col-lg-4 col-xl-4">

						<div class="news-wrapper mrb-30 mrb-sm-40">

							<div class="news-thumb">

								<img class="img-full" src="<?php echo esc_url($home_image);?>" alt="">

							</div>

							<div class="news-details pdt-25">

								<div class="news-description mb-20">

									<div class="news-bottom-meta mrb-15">

										<span class="entry-author mrr-20"><i class="far fa-user mrr-10 text-primary-color"></i><?php the_author_posts_link(); ?></span>

										<span class="entry-date"><i class="far fa-calendar-alt mrr-10 text-primary-color"></i><?php the_time(get_option( 'date_format'));?></span>

									</div>

									<h4 class="the-title mrb-20"><a href="<?php the_permalink();?>"><?php echo esc_attr($home_title); ?></a></h4>

									<p class="the-content"><?php if(isset($avitore_redux_demo['blog_excerpt'])){?>

										<?php echo esc_attr(avitore_excerpt3($avitore_redux_demo['blog_excerpt'])); ?>

									<?php }else{?>

										<?php echo esc_attr(avitore_excerpt3(15)); }?></p>

									</div>

									<div class="news-link">

										<a href="<?php the_permalink();?>"><?php if(isset($avitore_redux_demo['read_more'])){?>

											<?php echo htmlspecialchars_decode(esc_attr($avitore_redux_demo['read_more']));?>

										<?php }else{?>

											<?php echo esc_html__( 'Read more', 'avitore' ); }?> <i class="fal fa-long-arrow-right"></i></a>

										</div>

									</div>

								</div>

							</div>

							<?php 

						endwhile;  

						wp_reset_postdata();

					endif; 

					?>

				</div>

			</div>

		</div>

	</section>

		<?php endif; ?>

	<?php

	}



}