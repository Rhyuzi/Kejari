<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsCallto extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-callto';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Callto', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'callto' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_callto',

			[

				'label' => esc_html__( 'Callto Area', 'bdevs-elementor' ),

			]	

		);



		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'callto_type_1'  => esc_html__( 'Callto Type 1', 'bdevs-elementor' ),

					'callto_type_2' => esc_html__( 'Callto Type 2', 'bdevs-elementor' ),

				],

				'default'   => 'callto_type_1',

			]

		);



		$this->add_control(

			'image',

			[

				'label'   => esc_html__( 'Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::MEDIA,

				'dynamic' => [ 'active' => true ],

				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

            'title',

            [

                'label'       => __( 'Title', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),

                'default'     => __( 'It is Title', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        );  



		$this->add_control(

            'heading',

            [

                'label'       => __( 'Heading', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

                'default'     => __( 'It is Heading', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        );  



        $this->add_control(

            'content',

            [

                'label'       => __( 'Content', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXTAREA,

                'placeholder' => __( 'Enter your Content', 'bdevs-elementor' ),

                'default'     => __( 'It is Content', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        );  



        $this->add_control(

            'link',

            [

                'label'       => __( 'Link', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your Link', 'bdevs-elementor' ),

                'default'     => __( 'It is Link', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        ); 



        $this->add_control(

            'button',

            [

                'label'       => __( 'Button', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your Button', 'bdevs-elementor' ),

                'default'     => __( 'It is Button', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        ); 





		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_callto_2',

			[

				'label' => esc_html__( 'Callto Area 2', 'bdevs-elementor' ),

			]	

		);



		



        $this->add_control(

			'image_type_2',

			[

				'label'   => esc_html__( 'Image Type 2', 'bdevs-elementor' ),

				'type'    => Controls_Manager::MEDIA,

				'dynamic' => [ 'active' => true ],

				'description' => esc_html__( 'Add Your Image Type 2', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

            'title_type_2',

            [

                'label'       => __( 'Title Type 2', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your Title Type 2', 'bdevs-elementor' ),

                'default'     => __( 'It is Title Type 2', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        ); 



		$this->add_control(

            'heading_type_2',

            [

                'label'       => __( 'Heading Type 2', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your heading Type 2', 'bdevs-elementor' ),

                'default'     => __( 'It is Heading Type 2', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        );  



        $this->add_control(

            'content_type_2',

            [

                'label'       => __( 'Content Type 2', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXTAREA,

                'placeholder' => __( 'Enter your Content Type 2', 'bdevs-elementor' ),

                'default'     => __( 'It is Content Type 2', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        );  



        $this->add_control(

            'link_type_2',

            [

                'label'       => __( 'Link Type 2', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your Link Type 2', 'bdevs-elementor' ),

                'default'     => __( 'It is Link Type 2', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        ); 



        $this->add_control(

            'button_type_2',

            [

                'label'       => __( 'Button Type 2', 'bdevs-elementor' ),

                'type'        => Controls_Manager::TEXT,

                'placeholder' => __( 'Enter your Button Type 2', 'bdevs-elementor' ),

                'default'     => __( 'It is Button Type 2', 'bdevs-elementor' ),

                'label_block' => true,

            ]

        ); 







		$this->end_controls_section();







		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);			



		$this->add_control(

			'show_content',

			[

				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_image',

			[

				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->end_controls_section();



	}



public function render() {

	$settings  = $this->get_settings_for_display();

	$chose_style = $settings['chose_style'];

	extract($settings); ?>

		
	<h2 style="display: none;">1111111111</h2>
		<?php if( $chose_style == 'callto_type_1' ): ?>

		<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>

		<section class="pdt-110 pdb-110" data-background="<?php echo wp_kses_post($settings['image']['url']); ?>" data-overlay-dark="3">

		<?php endif; ?>	

			<div class="section-content">

				<div class="container">

					<div class="row">

						<div class="offset-lg-1 col-lg-10">

							<div class="text-divider text-center">

								<?php if ( '' !== $settings['title'] ) : ?>

								<h6 class="text-primary-color text-uppercase mrb-15"><?php echo wp_kses_post($settings['title']); ?></h6>

								<?php endif; ?>

								<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>

								<h2 class="mrt-0 large-text text-white mrb-20"><?php echo wp_kses_post($settings['heading']); ?></h2>

								<?php endif; ?>

								<?php if (( '' !== $settings['content'] ) && ( $settings['show_content'] )): ?>

								<p class="mrb-30 text-white"><?php echo wp_kses_post($settings['content']); ?></p>

								<?php endif; ?>

								<?php if (( '' !== $settings['button'] ) && ( $settings['show_button'] )): ?>

								<a href="<?php echo wp_kses_post($settings['link']); ?>" class="cs-btn-one btn-round btn-primary-color"><?php echo wp_kses_post($settings['button']); ?></a>

								<?php endif; ?>

							</div>

						</div>

					</div>

				</div>

			</div>

		</section>

	<?php elseif( $chose_style == 'callto_type_2' ): ?>

		<?php if (( '' !== $settings['image_type_2']['url'] ) && ( $settings['show_image'] )): ?>

		<section class="pdt-110 pdb-110" data-background="<?php echo wp_kses_post($settings['image_type_2']['url']); ?>" data-overlay-dark="3">

		<?php endif; ?>	

			<div class="section-content">

				<div class="container">

					<div class="row">

						<div class="offset-lg-1 col-lg-10">

							<div class="text-divider text-center">

								<?php if ( '' !== $settings['title_type_2'] ): ?>

								<h6 class="text-primary-color text-uppercase mrb-15"><?php echo wp_kses_post($settings['title_type_2']); ?></h6>

								<?php endif; ?>

								<?php if (( '' !== $settings['heading_type_2'] ) && ( $settings['show_heading'] )): ?>

								<h2 class="mrt-0 large-text text-white mrb-20"><?php echo wp_kses_post($settings['heading_type_2']); ?></h2>

								<?php endif; ?>

								<?php if (( '' !== $settings['content_type_2'] ) && ( $settings['show_content'] )): ?>

								<p class="mrb-30 text-white"><?php echo wp_kses_post($settings['content_type_2']); ?></p>

								<?php endif; ?>

								<?php if (( '' !== $settings['button_type_2'] ) && ( $settings['show_button'] )): ?>

								<a href="<?php echo wp_kses_post($settings['link_type_2']); ?>" class="cs-btn-one btn-round btn-gradient-color"><?php echo wp_kses_post($settings['button_type_2']); ?></a>

								<?php endif; ?>

							</div>

						</div>

					</div>

				</div>

			</div>

		</section>

	<?php endif; ?>

	<?php

	}



}