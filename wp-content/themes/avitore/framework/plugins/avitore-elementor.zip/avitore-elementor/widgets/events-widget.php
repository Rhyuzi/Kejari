<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsEvents extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-events';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Our Events', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'events' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_Events',
			[
				'label' => esc_html__( 'Events', 'bdevs-elementor' ),
			]
		);


		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'events-style-1'  => esc_html__( 'Events Style 1', 'bdevs-elementor' ),
					'events-style-2' => esc_html__( 'Events Style 2', 'bdevs-elementor' ),
				],
				'default'   => 'events-style-1',
			]
		);


		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Events Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Events Image', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'days',
			[
				'label'       => __( 'Days', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter days', 'bdevs-elementor' ),
				'default'     => __( 'It is Days', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'month_year',
			[
				'label'       => __( 'Month Year', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter Month Year', 'bdevs-elementor' ),
				'default'     => __( 'It is Month Year', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'post_number',
			[
				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'2'  => esc_html__( '2', 'bdevs-elementor' ),
					'4' => esc_html__( '4', 'bdevs-elementor' ),
					'6' => esc_html__( '6', 'bdevs-elementor' ),
					'8' => esc_html__( '8', 'bdevs-elementor' ),
				],
				'default'   => '2',
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);



		$this->add_control(
			'link',
			[
				'label'       => __( 'Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter link', 'bdevs-elementor' ),
				'default'     => __( 'It is Link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'button',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter text button', 'bdevs-elementor' ),
				'default'     => __( 'It is Text Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	


		$this->end_controls_section();




		$this->start_controls_section(
			'section_content_events_2',
			[
				'label' => esc_html__( 'Events 2', 'bdevs-elementor' ),
			]
		);


		

		$this->add_control(
			'post_number_2',
			[
				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'2'  => esc_html__( '2', 'bdevs-elementor' ),
					'4' => esc_html__( '4', 'bdevs-elementor' ),
					'6' => esc_html__( '6', 'bdevs-elementor' ),
					'8' => esc_html__( '8', 'bdevs-elementor' ),
				],
				'default'   => '2',
			]
		);

		$this->add_control(
			'post_order_2',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);



		$this->add_control(
			'link_2',
			[
				'label'       => __( 'Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter link', 'bdevs-elementor' ),
				'default'     => __( 'It is Link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'button_2',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter text button', 'bdevs-elementor' ),
				'default'     => __( 'It is Text Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	


		$this->end_controls_section();




		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'center',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);		

		$this->add_control(
			'show_image',
			[
				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->add_control(
			'show_content',
			[
				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_button',
			[
				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		

		$this->start_controls_section(
			'section_content_button',
			[
				'label'     => esc_html__( 'Button', 'bdevs-elementor' ),
				'condition' => [
					'show_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'bdevs-elementor' ),
				'placeholder' => esc_html__( 'Read More', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'icon',
			[
				'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => true,
			]
		);

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		$chose_style = $settings['chose_style'];
		$order = $settings['post_order'];
		$post_number = $settings['post_number'];

		$order_2 = $settings['post_order_2'];
		$post_number_2 = $settings['post_number_2'];

	    $wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'events',  'orderby' => 'ID', 'order' => 'ASC'));
	    

	    //other style
	    $args = array('posts_per_page' => $post_number,'post_type' => 'events',  'orderby' => 'ID', 'order' => 'ASC');

	    $wp_query2 = new \WP_Query(array('posts_per_page' => $post_number_2,'post_type' => 'events',  'orderby' => 'ID', 'order' => $order_2));
	    

	    //other style
	    $args2 = array('posts_per_page' => $post_number_2,'post_type' => 'events',  'orderby' => 'ID', 'order' => $order_2);

		if( $chose_style == 'events-style-1' ): ?>
		<div class="events-area pb-100">
			<div class="container">
				<div class="row">
					<div class="col-xl-10 col-lg-10 offset-lg-1 offset-xl-1">
						<div class="section-title text-center mb-85">
							<?php if (( '' !== $settings['heading'] ) && ( $settings['show_title'] )): ?>
							<h1><?php echo wp_kses_post($settings['heading']); ?></h1>
							<?php endif; ?>	

							<?php if (( '' !== $settings['sub_heading'] ) && ( $settings['show_content'] )): ?>
							<h2><?php echo wp_kses_post($settings['sub_heading']); ?></h2>
							<?php endif; ?>	
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-5 col-lg-5 mb-30">
						<div class="events-content text-md-center">
							<?php if ( '' !== $settings['days'] ) : ?>
							<h2><?php echo wp_kses_post($settings['days']); ?></h2>
							<?php endif; ?>	

							<?php if ( '' !== $settings['month_year'] ) : ?>
							<h1><?php echo wp_kses_post($settings['month_year']); ?></h1>
							<?php endif; ?>	


							<?php if (( '' !== $settings['button'] ) && ( $settings['show_button'] )) : ?>
							<a class="btn" href="<?php echo wp_kses_post($settings['link']); ?>"><span class="btn-text"><?php echo wp_kses_post($settings['button']); ?></span> <span class="btn-border"></span></a>
							<?php endif; ?>
						</div>
					</div>
					<div class="col-xl-7 col-lg-7">
						<div class="events-wrapper mb-30">
							<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>
							<div class="events-img">
								<img src="<?php echo wp_kses_post($settings['image']['url']); ?>" alt="">
							</div>
							<?php endif; ?>	
							<div class="events-bg">
								<div class="row">
		                        <?php 
                        		$args = new \WP_Query(array(   
                                    'post_type' => 'events', 
                                ));  
                                $i = 1;
                                while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
                                $i++;
                     
		                            $events_time = get_post_meta(get_the_ID(),'_cmb_events_time', true); 
		                            $events_date = get_post_meta(get_the_ID(),'_cmb_events_date', true); 
		                            $events_user = get_post_meta(get_the_ID(),'_cmb_events_user', true); 
		                            $events_subtitle = get_post_meta(get_the_ID(),'_cmb_events_subtitle', true); 
		                            ?>
									<div class="col-xl-6 col-lg-6 mb-30">
										<div class="single-events">
											<div class="events-text">
												<span><?php echo htmlspecialchars_decode(esc_attr($events_subtitle));?></span>
												<h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
												<div class="event-meta">
													<span> <i class="far fa-clock"></i> <?php echo htmlspecialchars_decode(esc_attr($events_time));?></span>
													<span> <i class="far fa-users"></i> <?php echo htmlspecialchars_decode(esc_attr($events_user));?></span>
													<span> <i class="far fa-calendar-alt"></i> <?php echo htmlspecialchars_decode(esc_attr($events_date));?></span>
												</div>
												<a href="<?php the_permalink();?>"><?php if(isset($avitore_redux_demo['read_more'])){?>
                                        <?php echo htmlspecialchars_decode(esc_attr($avitore_redux_demo['read_more']));?>
                                        <?php }else{ ?>
                                        <?php echo esc_html__( 'Read more', 'avitore' );}?>
                                        </a>
											</div>
										</div>
									</div>
									<?php   
				        endwhile; 
				        wp_reset_postdata();
				    ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php elseif( $chose_style == 'events-style-2' ): ?>
			<div class="event-list-area pt-130 pb-130">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-10 offset-xl-1">
                        	<?php 
                            	$args2 = new \WP_Query(array(   
                            		'post_type' => 'events', 
                            	));  
                            	$i = 1;
                            	while ($wp_query2 -> have_posts()) : $wp_query2 -> the_post(); 
                            		$i++;

                            		$events_time = get_post_meta(get_the_ID(),'_cmb_events_time', true); 
                            		$events_date = get_post_meta(get_the_ID(),'_cmb_events_date', true); 
                            		$events_user = get_post_meta(get_the_ID(),'_cmb_events_user', true); 
                            		$events_price = get_post_meta(get_the_ID(),'_cmb_events_price', true); 
                            		$events_excerpt = get_post_meta(get_the_ID(),'_cmb_events_excerpt', true); 
                            		$events_image = get_post_meta(get_the_ID(),'_cmb_events_image_2', true); 
                            		?>
                            <div class="row no-gutters">
                                <div class="col-xl-6 col-lg-6 mb-30">
                                    <div class="event-list-img">
                                        <img src="<?php echo esc_url($events_image);?>" alt="">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 mb-30">
                                    <div class="upcoming-text upcoming-2-text">
                                        <div class="up-tag">
                                            <span><?php echo htmlspecialchars_decode(esc_attr($events_price));?></span>
                                        </div>
                                        <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                        <div class="up-event-meta">
                                            <span> <i class="far fa-calendar-alt"></i> <?php echo htmlspecialchars_decode(esc_attr($events_date));?></span>
                                            <span> <i class="far fa-clock"></i> <?php echo htmlspecialchars_decode(esc_attr($events_time));?></span>
                                            <span> <i class="far fa-users"></i> <?php echo htmlspecialchars_decode(esc_attr($events_user));?></span>
                                        </div>
                                        <p><?php echo htmlspecialchars_decode(esc_attr($events_excerpt));?> </p>
                                         <a class="btn" href="<?php the_permalink();?>"><span class="btn-text"><?php if(isset($avitore_redux_demo['book_ticket'])){?>
                                        <?php echo htmlspecialchars_decode(esc_attr($avitore_redux_demo['book_ticket']));?>
                                        <?php }else{ ?>
                                        <?php echo esc_html__( 'View Details', 'avitore' );}?></span> <span class="btn-border"></span></a>
                                    </div>
                                </div>
                            </div>
                            <?php   
				        endwhile; 
				        wp_reset_postdata();
				    ?>
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="event-list-button text-center mt-60">
                                    	<?php if (( '' !== $settings['button_2'] ) && ( $settings['show_button'] )) : ?>
                                    	<a class="btn" href="<?php echo wp_kses_post($settings['link_2']); ?>"><span class="btn-text"><?php echo wp_kses_post($settings['button_2']); ?></span> <span class="btn-border"></span></a>
                                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>	
	<?php
	}

}