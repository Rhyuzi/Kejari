<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsServices extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-services';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Services Area', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'services' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_Services',

			[

				'label' => esc_html__( 'Services', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'services_type_1'  => esc_html__( 'Services Type 1', 'bdevs-elementor' ),

					'services_type_2' => esc_html__( 'Services Type 2', 'bdevs-elementor' ),

					'services_type_3' => esc_html__( 'Services Type 3', 'bdevs-elementor' ),

				],

				'default'   => 'services_type_1',

			]

		);



		$this->add_control(

			'heading',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'sub_heading',

			[

				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);



		$this->add_control(

			'post_number',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'3'  => esc_html__( '3', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'9' => esc_html__( '9', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

				],

				'default'   => '6',

			]

		);



		$this->add_control(

			'post_order',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_services_2',

			[

				'label' => esc_html__( 'Services 2', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'image_type_2',

			[

				'label'       => __( 'Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::MEDIA,

				'dynamic' => [ 'active' => true ],

				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),

			]

		);	



		$this->add_control(

			'heading_type_2',

			[

				'label'       => __( 'Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	



		$this->add_control(

			'sub_heading_type_2',

			[

				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),

				'type'        => Controls_Manager::TEXT,

				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),

				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),

				'label_block' => true,

			]

		);	





		$this->add_control(

			'post_number2',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'2'  => esc_html__( '2', 'bdevs-elementor' ),

					'4' => esc_html__( '4', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'8' => esc_html__( '8', 'bdevs-elementor' ),

				],

				'default'   => '6',

			]

		);



		$this->add_control(

			'post_order2',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_services_3',

			[

				'label' => esc_html__( 'Services 3', 'bdevs-elementor' ),

			]

		);



		$this->add_control(

			'image_type_3',

			[

				'label'       => __( 'Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::MEDIA,

				'dynamic' => [ 'active' => true ],

				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),

			]

		);	



		$this->add_control(

			'post_number3',

			[

				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'3'  => esc_html__( '3', 'bdevs-elementor' ),

					'6' => esc_html__( '6', 'bdevs-elementor' ),

					'9' => esc_html__( '9', 'bdevs-elementor' ),

					'12' => esc_html__( '12', 'bdevs-elementor' ),

				],

				'default'   => '6',

			]

		);



		$this->add_control(

			'post_order3',

			[

				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),

					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),

				],

				'default'   => 'desc',

			]

		);



		$this->end_controls_section();







		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);	



		$this->add_control(

			'show_sub_heading',

			[

				'label'   => esc_html__( 'Show Sub Heading', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);	



		$this->add_control(

			'show_image',

			[

				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->end_controls_section();



		

	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		$chose_style = $settings['chose_style'];

		$order = $settings['post_order'];

		$post_number = $settings['post_number'];

		$order2 = $settings['post_order2'];

		$post_number2 = $settings['post_number2'];

		$order3 = $settings['post_order3'];

		$post_number3 = $settings['post_number3'];

		$wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'service',  'orderby' => 'ID', 'order' => $order));

		$wp_query2 = new \WP_Query(array('posts_per_page' => $post_number2,'post_type' => 'service',  'orderby' => 'ID', 'order' => $order2));

		$wp_query3 = new \WP_Query(array('posts_per_page' => $post_number3,'post_type' => 'service',  'orderby' => 'ID', 'order' => $order3));

		?>
		<h2 style="display: none;">1111111111</h2>
		<?php if( $chose_style == 'services_type_1' ): ?>



	<section class="service-section bg-light-pink pdt-110 pdt-lg-105 pdb-80">

		<div class="section-title text-center wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">

			<div class="container">

				<div class="row">

					<div class="col"></div>

					<div class="col-lg-8 col-xl-6">

						<div class="section-title-block">

							<?php if (( '' !== $settings['sub_heading'] ) && ( $settings['show_sub_heading'] )): ?>

							<h5 class="text-primary-color anim-box-objects text-underline mrb-15"><?php echo wp_kses_post($settings['sub_heading']); ?></h5>

							<?php endif; ?>

							<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>

							<h2><?php echo wp_kses_post($settings['heading']); ?></h2>

							<?php endif; ?>

						</div>

					</div>

					<div class="col"></div>

				</div>

			</div>

		</div>

		<div class="section-content">

			<div class="container">

			<div class="row">

				<?php 

				$args = new \WP_Query(array(   

					'post_type' => 'service', 

				));  

				while ($wp_query -> have_posts()) : $wp_query -> the_post(); 



				$service_excerpt = get_post_meta(get_the_ID(),'_cmb_service_excerpt', true);

				$service_icon = get_post_meta(get_the_ID(),'_cmb_service_icon', true);

				?>

				<div class="col-md-6 col-lg-4 col-xl-4">

					<div class="features-item">

						<i class="<?php echo esc_attr($service_icon); ?>"></i>

						<h4 class="feature-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>

						<p class="mrb-0"><?php echo esc_attr($service_excerpt);?></p>

					</div>

				</div>

				<?php endwhile; ?>

			</div>

			</div>

		</div>

	</section>

		<?php elseif( $chose_style == 'services_type_2' ): ?>

	<?php if (( '' !== $settings['image_type_2']['url'] ) && ( $settings['show_image'] )): ?>

	<section class="service-section pdt-110 pdt-lg-105 pdb-80" data-background="<?php echo wp_kses_post($settings['image_type_2']['url']); ?>">

	<?php endif; ?>	

		<div class="section-title text-center wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">

			<div class="container">

				<div class="row">

					<div class="col"></div>

					<div class="col-lg-8 col-xl-6">

						<div class="section-title-block">

							<?php if (( '' !== $settings['sub_heading_type_2'] ) && ( $settings['show_sub_heading'] )): ?>

							<h5 class="text-primary-color anim-box-objects text-underline mrb-15"><?php echo wp_kses_post($settings['sub_heading_type_2']); ?></h5>

							<?php endif; ?>

							<?php if (( '' !== $settings['heading_type_2'] ) && ( $settings['show_heading'] )): ?>

							<h2><?php echo wp_kses_post($settings['heading_type_2']); ?></h2>

							<?php endif; ?>

						</div>

					</div>

					<div class="col"></div>

				</div>

			</div>

		</div>

		<div class="section-content">

			<div class="container">

			<div class="row">

				<?php 

				$args = new \WP_Query(array(   

					'post_type' => 'service', 

				));  

				while ($wp_query2 -> have_posts()) : $wp_query2 -> the_post(); 



				$service_excerpt = get_post_meta(get_the_ID(),'_cmb_service_excerpt', true);

				$service_icon = get_post_meta(get_the_ID(),'_cmb_service_icon', true);

				?>

				<div class="col-md-6 col-lg-4 col-xl-4">

					<div class="features-item">

						<i class="<?php echo esc_attr($service_icon); ?>"></i>

						<h4 class="feature-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>

						<p class="mrb-0"><?php echo esc_attr($service_excerpt);?></p>

					</div>

				</div>

				<?php endwhile; ?>

			</div>

			</div>

		</div>

	</section>

		<?php elseif( $chose_style == 'services_type_3' ): ?>

			<?php if (( '' !== $settings['image_type_3']['url'] ) && ( $settings['show_image'] )): ?>

			<section class="service-section pdt-110 pdt-lg-105 pdb-80" data-background="<?php echo wp_kses_post($settings['image_type_3']['url']); ?>">

			<?php endif; ?>	

					<div class="section-content">

						<div class="container">

							<div class="row">

								<?php 

								$args = new \WP_Query(array(   

									'post_type' => 'service', 

								));  

								while ($wp_query3 -> have_posts()) : $wp_query3 -> the_post(); 



								$service_excerpt = get_post_meta(get_the_ID(),'_cmb_service_excerpt', true);

								$service_icon = get_post_meta(get_the_ID(),'_cmb_service_icon', true);

								?>

								<div class="col-md-6 col-lg-4 col-xl-4">

									<div class="features-item">

										<i class="<?php echo esc_attr($service_icon); ?>"></i>

										<h4 class="feature-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>

										<p class="mrb-0"><?php echo esc_attr($service_excerpt);?></p>

									</div>

								</div>

								<?php endwhile; ?>

							</div>

						</div>

					</div>

				</section>

		<?php endif; ?>	

	<?php

	}



}