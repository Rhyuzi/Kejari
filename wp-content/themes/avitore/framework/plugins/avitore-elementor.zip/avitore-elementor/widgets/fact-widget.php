<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsFact extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-fact';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Fact', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'fact' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_fact',
			[
				'label' => esc_html__( 'Fact', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'fact_type_1'  => esc_html__( 'Fact Type 1', 'bdevs-elementor' ),
					'fact_type_2' => esc_html__( 'Fact Type 2', 'bdevs-elementor' ),
				],
				'default'   => 'fact_type_1',
			]
		);
		
		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Fact Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Fact One', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Fact Two', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Support Content Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Fact Three', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
				],
				'fields' => [
					[
						'name'        => 'tab_option',
						'label'       => esc_html__( 'Option', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Option' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_number',
						'label'       => esc_html__( 'Number', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Number' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
					],
					[
						'name'        => 'tab_delay',
						'label'       => esc_html__( 'Delay', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Delay' , 'bdevs-elementor' ),
					],
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_fact_2',
			[
				'label' => esc_html__( 'Fact 2', 'bdevs-elementor' ),
			]	
		);
		
		$this->add_control(
			'image_type_2',
			[
				'label'   => esc_html__( 'Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_type_2',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'sub_heading_type_2',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Sub Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'desc_type_2',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your Description', 'bdevs-elementor' ),
				'default'     => __( 'It is Description', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'tabs_2',
			[
				'label' => esc_html__( 'Fact Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Fact One', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Fact Two', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Support Content Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Fact Three', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
				],
				'fields' => [
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_number',
						'label'       => esc_html__( 'Number', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Number' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
					],
					[
						'name'        => 'tab_delay',
						'label'       => esc_html__( 'Delay', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Delay' , 'bdevs-elementor' ),
					],
				],
			]
		);

		$this->add_control(
			'heading_2_type_2',
			[
				'label'       => __( 'Heading 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading 2', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading 2', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'sub_heading_2_type_2',
			[
				'label'       => __( 'Sub Heading 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your sub heading 2', 'bdevs-elementor' ),
				'default'     => __( 'It is Sub Heading 2', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->end_controls_section();		
		

		
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'center',
			]
		);

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_sub_heading',
			[
				'label'   => esc_html__( 'Show Sub Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_image',
			[
				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->add_control(
			'show_button',
			[
				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		$chose_style = $settings['chose_style'];
		extract($settings);
		?>
		<?php if( $chose_style == 'fact_type_1' ): ?>
		<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>
		<section class="pdt-110 pdb-50 section-white-typo" data-background="<?php echo wp_kses_post($settings['image']['url']); ?>" data-overlay-dark="3">
		<?php endif; ?> 
			<div class="section-title text-center mrb-80">
				<div class="container">
					<div class="row">
						<div class="col"></div>
						<div class="col-xl-6">
							<div class="section-title-block">
								<?php if (( '' !== $settings['sub_heading'] ) && ( $settings['show_sub_heading'] )): ?>
								<h5 class="subtitle-block"><?php echo wp_kses_post($settings['sub_heading']); ?></h5>
								<?php endif; ?>
								<?php if (( '' !== $settings['heading'] ) && ( $settings['show_heading'] )): ?>
								<h2 class=""><?php echo wp_kses_post($settings['heading']); ?></h2>
								<?php endif; ?>
							</div>
						</div>
						<div class="col"></div>
					</div>
				</div>
			</div>
			<div class="section-content">
				<div class="container">
					<div class="row">
						<?php foreach ( $settings['tabs'] as $item ) : ?>
							<div class="col-md-6 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="<?php echo wp_kses_post($item['tab_delay']); ?>" data-wow-duration="800ms">
								<div class="funfact mrb-md-70 mrb-60">
									<?php if ( '' !== $item['tab_icon'] ): ?>
									<div class="icon">
										<span class="webexflaticon <?php echo wp_kses_post($item['tab_icon']); ?>"></span>
									</div>
									<?php endif; ?>
									<?php if ( '' !== $item['tab_number'] ): ?>
									<h2 class="counter"><?php echo wp_kses_post($item['tab_number']); ?></h2>
									<?php endif; ?>
									<?php if ( '' !== $item['tab_option'] ): ?>
									<h5 class="title"><?php echo wp_kses_post($item['tab_option']); ?></h5>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</section>
		<?php elseif( $chose_style == 'fact_type_2' ): ?>
		<?php if (( '' !== $settings['image_type_2']['url'] ) && ( $settings['show_image'] )): ?>
		<section class="request-a-call-back bg-cover pdt-110 pdb-70 pdb-lg-90" data-background="<?php echo wp_kses_post($settings['image_type_2']['url']); ?>">
		<?php endif; ?>
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-lg-7 col-xl-7 wow fadeInLeft mrb-lg-40" data-wow-delay="0ms" data-wow-duration="1000ms">
						<?php if (( '' !== $settings['sub_heading_type_2'] ) && ( $settings['show_sub_heading'] )): ?>
						<h5 class="subtitle-block"><?php echo wp_kses_post($settings['sub_heading_type_2']); ?></h5>
						<?php endif; ?>
						<?php if (( '' !== $settings['heading_type_2'] ) && ( $settings['show_heading'] )): ?>
						<h2 class="mrb-20"><?php echo wp_kses_post($settings['heading_type_2']); ?></h2>
						<?php endif; ?>
						<?php if ( '' !== $settings['desc_type_2'] ) : ?>
						<p class="mrb-60"><?php echo wp_kses_post($settings['desc_type_2']); ?></p>
						<?php endif; ?>
						<div class="row">
							<?php foreach ( $settings['tabs_2'] as $item ) : ?>
								<?php if ( '' !== $item['tab_delay'] ) : ?>
								<div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="<?php echo wp_kses_post($item['tab_delay']); ?>" data-wow-duration="800ms">
								<?php endif; ?>	
									<div class="funfact text-md-left mrb-md-70 mrb-60">
										<?php if ( '' !== $item['tab_icon'] ) : ?>
										<div class="icon">
											<span class="webexflaticon <?php echo wp_kses_post($item['tab_icon']); ?>"></span>
										</div>
										<?php endif; ?>	
										<?php if ( '' !== $item['tab_number'] ) : ?>
										<h2 class="counter"><?php echo wp_kses_post($item['tab_number']); ?></h2>
										<?php endif; ?>	
										<?php if ( '' !== $item['tab_title'] ) : ?>
										<h5 class="title"><?php echo wp_kses_post($item['tab_title']); ?></h5>
										<?php endif; ?>	
									</div>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
					<div class="col-md-12 col-lg-5 col-xl-5 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
						<div class="request-a-call-back-form">
							<?php if ( '' !== $settings['heading_2_type_2'] ) : ?>
							<h3 class="mrt-0 mrb-15 text-white"><?php echo wp_kses_post($settings['heading_2_type_2']); ?></h3>
							<?php endif; ?>
							<?php if ( '' !== $settings['sub_heading_2_type_2'] ) : ?>
							<p class="text-white mrb-30"><?php echo wp_kses_post($settings['sub_heading_2_type_2']); ?></p>
							<?php endif; ?>
							<?php echo do_shortcode('[contact-form-7 id="146" title="Request a call back"]'); ?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php endif; ?>
	<?php
	}
}