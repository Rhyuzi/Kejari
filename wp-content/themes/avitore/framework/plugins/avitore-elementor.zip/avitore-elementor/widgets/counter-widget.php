<?php

namespace BdevsElementor\Widget;



use Elementor\Controls_Manager;

use Elementor\Group_Control_Typography;

use Elementor\Scheme_Typography;

use Elementor\Group_Control_Border;

use Elementor\Group_Control_Box_Shadow;



/**

 * Bdevs Elementor Widget.

 *

 * Elementor widget that inserts an embbedable content into the page, from any given URL.

 *

 * @since 1.0.0

 */

class BdevsCounter extends \Elementor\Widget_Base {



	/**

	 * Get widget name.

	 *

	 * Retrieve Bdevs Elementor widget name.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget name.

	 */

	public function get_name() {

		return 'bdevs-counter';

	}



	/**

	 * Get widget title.

	 *

	 * Retrieve Bdevs Elementor widget title.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget title.

	 */

	public function get_title() {

		return __( 'Counter', 'bdevs-elementor' );

	}



	/**

	 * Get widget icon.

	 *

	 * Retrieve Bdevs Slider widget icon.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return string Widget icon.

	 */

	public function get_icon() {

		return 'eicon-favorite';

	}



	/**

	 * Get widget categories.

	 *

	 * Retrieve the list of categories the Bdevs Slider widget belongs to.

	 *

	 * @since 1.0.0

	 * @access public

	 *

	 * @return array Widget categories.

	 */

	public function get_categories() {

		return [ 'bdevs-elementor' ];

	}



	public function get_keywords() {

		return [ 'counter' ];

	}



	public function get_script_depends() {

		return [ 'bdevs-elementor'];

	}



	// BDT Position

	protected function element_pack_position() {

	    $position_options = [

	        ''              => esc_html__('Default', 'bdevs-elementor'),

	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,

	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,

	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,

	        'center'        => esc_html__('Center', 'bdevs-elementor') ,

	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,

	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,

	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,

	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,

	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,

	    ];



	    return $position_options;

	}



	protected function _register_controls() {

		$this->start_controls_section(

			'section_content_features',

			[

				'label' => esc_html__( 'Counter Area', 'bdevs-elementor' ),

			]	

		);



		$this->add_control(

			'chose_style',

			[

				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),

				'type'      => Controls_Manager::SELECT,

				'options'   => [

					'counter-style-1'  => esc_html__( 'Counter Home 1', 'bdevs-elementor' ),

					'counter-style-2' => esc_html__( 'Counter Home 2', 'bdevs-elementor' ),

					'counter-style-3' => esc_html__( 'Counter About', 'bdevs-elementor' ),

				],

				'default'   => 'counter-style-1',

			]

		);



		$this->add_control(

			'image',

			[

				'label'   => esc_html__( 'Counter Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::MEDIA,

				'dynamic' => [ 'active' => true ],

				'description' => esc_html__( 'Add Your Counter Image', 'bdevs-elementor' ),

			]

		);



		

		$this->add_control(

			'tabs',

			[

				'label' => esc_html__( 'Counter Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Counter #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [				

					[

						'name'        => 'tab_title',

						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'tab_subtitle',

						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),

						'label_block' => true,

					],	

					[

						'name'        => 'tab_icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

				],

			]

		);





		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_counter_2',

			[

				'label' => esc_html__( 'Counter Area 2', 'bdevs-elementor' ),

			]	

		);







		$this->add_control(

			'tabs_2',

			[

				'label' => esc_html__( 'Counter Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Counter #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [				

					[

						'name'        => 'tab_title',

						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'tab_subtitle',

						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),

						'label_block' => true,

					],	

					[

						'name'        => 'tab_icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

				],

			]

		);





		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_counter_3',

			[

				'label' => esc_html__( 'Counter Area 3', 'bdevs-elementor' ),

			]	

		);







		$this->add_control(

			'tabs_3',

			[

				'label' => esc_html__( 'Counter Items', 'bdevs-elementor' ),

				'type' => Controls_Manager::REPEATER,

				'default' => [

					[

						'tab_title'   => esc_html__( 'Counter #1', 'bdevs-elementor' ),

						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),

					]

				],

				'fields' => [				

					[

						'name'        => 'tab_title',

						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),

						'label_block' => true,

					],

					[

						'name'        => 'tab_subtitle',

						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),

						'label_block' => true,

					],	

					[

						'name'        => 'tab_icon',

						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),

						'type'        => Controls_Manager::TEXT,

						'dynamic'     => [ 'active' => true ],

						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),

						'label_block' => true,

					],

				],

			]

		);





		$this->end_controls_section();





		$this->start_controls_section(

			'section_content_layout',

			[

				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),

			]

		);



		$this->add_responsive_control(

			'align',

			[

				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),

				'type'    => Controls_Manager::CHOOSE,

				'options' => [

					'left' => [

						'title' => esc_html__( 'Left', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-left',

					],

					'center' => [

						'title' => esc_html__( 'Center', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-center',

					],

					'right' => [

						'title' => esc_html__( 'Right', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-right',

					],

					'justify' => [

						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),

						'icon'  => 'fa fa-align-justify',

					],

				],

				'prefix_class' => 'elementor%s-align-',

				'description'  => 'Use align to match position',

				'default'      => 'center',

			]

		);



		$this->add_control(

			'show_heading',

			[

				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);			



		$this->add_control(

			'show_sub_heading',

			[

				'label'   => esc_html__( 'Show Sub Title', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);		



		$this->add_control(

			'show_image',

			[

				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->add_control(

			'show_content',

			[

				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);



		$this->add_control(

			'show_button',

			[

				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),

				'type'    => Controls_Manager::SWITCHER,

				'default' => 'yes',

			]

		);





		$this->end_controls_section();



	}



	public function render() {

		$settings  = $this->get_settings_for_display();

		$chose_style = $settings['chose_style'];

		extract($settings);

		

		if( $chose_style == 'counter-style-1' ): ?>
		<h2 style="display: none;">1111111111</h2>
		

		<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>

		<section class="pdt-110 pdb-40" data-background="<?php echo wp_kses_post($settings['image']['url']); ?>" data-overlay-dark="4">

		<?php endif; ?>	

		<div class="section-content section-white-typo text-center">

			<div class="container">

				<div class="row">

					<?php foreach ( $settings['tabs'] as $item ) : ?>

						<div class="col-md-6 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="800ms">

							<div class="funfact mrb-md-70 mrb-60">

								<?php if ( '' !== $item['tab_icon'] ) : ?>

								<div class="icon">

									<span class="<?php echo wp_kses_post($item['tab_icon']); ?>"></span>

								</div>

								<?php endif; ?>	

								<?php if ( '' !== $item['tab_title'] ) : ?>

									<h2 class="counter"><?php echo wp_kses_post($item['tab_title']); ?></h2>

								<?php endif; ?>	



								<?php if ( '' !== $item['tab_subtitle'] ) : ?>

									<h5 class="title"><?php echo wp_kses_post($item['tab_subtitle']); ?></h5>

								<?php endif; ?>	

							</div>

						</div>

					<?php endforeach; ?>

				</div>

			</div>

		</div>

	</section>



		<?php elseif( $chose_style == 'counter-style-2' ): ?>

		

		<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>

		 <div class="counter-area pt-400 pb-100" style="background-image:url(<?php echo wp_kses_post($settings['image']['url']); ?>)">

		 	<?php endif; ?>		

                <div class="container">

                    <div class="row justify-content-between">

                    	<?php foreach ( $settings['tabs_2'] as $item ) : ?>

                        <div class="col-xl-3 col-lg-3 col-md-6">

                            <div class="counter-wrapper single-counter text-center mb-30">

                            	<?php if ( '' !== $item['tab_icon'] ) : ?>

                                <div class="counter-icon">

                                    <i class="<?php echo wp_kses_post($item['tab_icon']); ?>"></i>

                                </div>

                                <?php endif; ?>	

                                <div class="counter-text">

                                	<?php if ( '' !== $item['tab_title'] ) : ?>

                                    <h1><?php echo wp_kses_post($item['tab_title']); ?></h1>

                                    <?php endif; ?>	

                                    <?php if ( '' !== $item['tab_subtitle'] ) : ?>

                                    <p><?php echo wp_kses_post($item['tab_subtitle']); ?></p>

                                    <?php endif; ?>	

                                </div>

                            </div>

                        </div>

                        <?php

		 				endforeach;

		 				?>

                    </div>

                </div>

            </div>

        <?php elseif( $chose_style == 'counter-style-3' ): ?>

			<div class="counter-area pt-130 pb-150">

                <div class="container">

                    <div class="row justify-content-between">

                    	<?php foreach ( $settings['tabs_3'] as $item ) : ?>

                        <div class="col-xl-3 col-lg-3 col-md-6">

                            <div class="counter-wrapper single-counter single-2-counter text-center mb-30">

                                <?php if ( '' !== $item['tab_icon'] ) : ?>

                                <div class="counter-icon">

                                    <i class="<?php echo wp_kses_post($item['tab_icon']); ?>"></i>

                                </div>

                                <?php endif; ?>

                                <div class="counter-text">

                                	<?php if ( '' !== $item['tab_title'] ) : ?>

                                    <h1><?php echo wp_kses_post($item['tab_title']); ?></h1>

                                    <?php endif; ?>	

                                    <?php if ( '' !== $item['tab_subtitle'] ) : ?>

                                    <p><?php echo wp_kses_post($item['tab_subtitle']); ?></p>

                                    <?php endif; ?>	

                                </div>

                            </div>

                        </div>

                        <?php

		 				endforeach;

		 				?>

                    </div>

                </div>

            </div>

		<?php endif; ?>	

	<?php

	}



}