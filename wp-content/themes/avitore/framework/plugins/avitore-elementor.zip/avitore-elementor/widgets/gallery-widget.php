<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsGallery extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-gallery';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Our Gallery', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs gallery widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs gallery widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'gallery' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_gallery',
			[
				'label' => esc_html__( 'Gallery', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'gallery_home_1'  => esc_html__( 'Gallery Home 1', 'bdevs-elementor' ),
					'gallery_home_2' => esc_html__( 'Gallery Home 2', 'bdevs-elementor' ),
					'gallery_home_3' => esc_html__( 'Gallery Home 3', 'bdevs-elementor' ),
					'gallery_home_4' => esc_html__( 'Gallery Home 4', 'bdevs-elementor' ),
				],
				'default'   => 'gallery_home_1',
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Gallery Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your gallery Image', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	


		$this->add_control(
			'link',
			[
				'label'       => __( 'Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter link', 'bdevs-elementor' ),
				'default'     => __( 'It is Link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'button',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter text button', 'bdevs-elementor' ),
				'default'     => __( 'It is Text Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'tabs1',
			[
				'label' => esc_html__( 'Gallery Items 1', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Gallery #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Gallery #2', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
				],
				'fields' => [					
									
					[
						'name'        => 'video_link',
						'label'       => esc_html__( 'Link Video', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => __( 'It is Video Link.', 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'       => 'tab_link',
						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),
						'type'       => Controls_Manager::TEXT,
						'dynamic'    => [ 'active' => true ],
						'default'     => __( 'It is Link.', 'bdevs-elementor' ),
						'show_label' => false,
					],
					[
						'name'    => 'tab_image',
						'label'   => esc_html__( 'Tab Image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
					],	
				],
			]
		);

		$this->add_control(
			'tabs2',
			[
				'label' => esc_html__( 'Gallery Items 2', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Gallery #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Gallery #2', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
				],
				'fields' => [				
					[
						'name'        => 'video_link',
						'label'       => esc_html__( 'Link Video', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => __( 'It is Video Link.', 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'       => 'tab_link',
						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),
						'type'       => Controls_Manager::TEXT,
						'dynamic'    => [ 'active' => true ],
						'default'     => __( 'It is Link.', 'bdevs-elementor' ),
						'show_label' => false,
					],
					[
						'name'    => 'tab_image',
						'label'   => esc_html__( 'Tab Image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
					],	
				],
			]
		);

		$this->add_control(
			'tabs3',
			[
				'label' => esc_html__( 'Gallery Items 3', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Gallery #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Gallery #2', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
				],
				'fields' => [					
									
					[
						'name'        => 'video_link',
						'label'       => esc_html__( 'Link Video', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => __( 'It is Video Link.', 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'       => 'tab_link',
						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),
						'type'       => Controls_Manager::TEXT,
						'dynamic'    => [ 'active' => true ],
						'default'     => __( 'It is Link.', 'bdevs-elementor' ),
						'show_label' => false,
					],
					[
						'name'    => 'tab_image',
						'label'   => esc_html__( 'Tab Image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
					],	
				],
			]
		);

		$this->add_control(
			'tabs4',
			[
				'label' => esc_html__( 'Gallery Items 4', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'Gallery #1', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'Gallery #2', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'I am item content. Click edit button to change this text.', 'bdevs-elementor' ),
					],
				],
				'fields' => [					
									
					[
						'name'        => 'video_link',
						'label'       => esc_html__( 'Link Video', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => __( 'It is Video Link.', 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'       => 'tab_link',
						'label'      => esc_html__( 'Link', 'bdevs-elementor' ),
						'type'       => Controls_Manager::TEXT,
						'dynamic'    => [ 'active' => true ],
						'default'     => __( 'It is Link.', 'bdevs-elementor' ),
						'show_label' => false,
					],
					[
						'name'    => 'tab_image',
						'label'   => esc_html__( 'Tab Image', 'bdevs-elementor' ),
						'type'    => Controls_Manager::MEDIA,
						'dynamic' => [ 'active' => true ],
					],	
				],
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_gallery_2',
			[
				'label' => esc_html__( 'Gallery Home 2', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'image_home_2',
			[
				'label'   => esc_html__( 'Gallery Image Home 2', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your gallery Image', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading_home_2',
			[
				'label'       => __( 'Heading Home 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'sub_heading_home_2',
			[
				'label'       => __( 'Sub heading Home 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	


		$this->add_control(
			'post_number',
			[
				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'3'  => esc_html__( '3', 'bdevs-elementor' ),
					'6' => esc_html__( '6', 'bdevs-elementor' ),
					'9' => esc_html__( '9', 'bdevs-elementor' ),
					'12' => esc_html__( '12', 'bdevs-elementor' ),
				],
				'default'   => '6',
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);

		$this->end_controls_section();




		$this->start_controls_section(
			'section_content_gallery_3',
			[
				'label' => esc_html__( 'Gallery Home 3', 'bdevs-elementor' ),
			]
		);

		


		$this->add_control(
			'post_number_2',
			[
				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'3'  => esc_html__( '3', 'bdevs-elementor' ),
					'6' => esc_html__( '6', 'bdevs-elementor' ),
					'9' => esc_html__( '9', 'bdevs-elementor' ),
					'12' => esc_html__( '12', 'bdevs-elementor' ),
				],
				'default'   => '6',
			]
		);

		$this->add_control(
			'post_order_2',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'ASC'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'DESC' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'DESC',
			]
		);

		$this->end_controls_section();


		

		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'center',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);		

		$this->add_control(
			'show_image',
			[
				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->add_control(
			'show_content',
			[
				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_button',
			[
				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

		

		$this->start_controls_section(
			'section_content_button',
			[
				'label'     => esc_html__( 'Button', 'bdevs-elementor' ),
				'condition' => [
					'show_button' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Text', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'bdevs-elementor' ),
				'placeholder' => esc_html__( 'Read More', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'icon',
			[
				'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => true,
			]
		);

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		$chose_style = $settings['chose_style'];
		$order = $settings['post_order'];
		$post_number = $settings['post_number'];
		$order_2 = $settings['post_order_2'];
		$post_number_2 = $settings['post_number_2'];

		$wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'gallery',  'orderby' => 'ID', 'order' => 'ASC'));
	    

	    //other style
	    $args = array('posts_per_page' => $post_number,'post_type' => 'gallery',  'orderby' => 'ID', 'order' => 'ASC');

	    $wp_query2 = new \WP_Query(array('posts_per_page' => $post_number_2,'post_type' => 'gallery',  'orderby' => 'ID', 'order' => '$order_2'));
	    

	    //other style
	    $args2 = array('posts_per_page' => $post_number_2,'post_type' => 'gallery',  'orderby' => 'ID', 'order' => '$order_2');
		?>
		<?php if( $chose_style == 'gallery_home_1' ): ?>
		<div class="gallery-area fix">
                <div class="row no-gutters">
                    <div class="col-xl-6 col-lg-6">
                        <div class="gallery-wrapper">
                            <div class="gallery-img">
                            	<?php if (( '' !== $settings['image']['url'] ) && ( $settings['show_image'] )): ?>
                                <a href="<?php echo wp_kses_post($settings['link']); ?>"><img src="<?php echo wp_kses_post($settings['image']['url']); ?>" alt=""></a>
                                <?php endif; ?>
                                <div class="gallery-content text-center">
                                    <span></span>
                                    <?php if (( '' !== $settings['heading'] ) && ( $settings['show_title'] )): ?>
                                    <h1><a href="<?php echo wp_kses_post($settings['link']); ?>"><?php echo wp_kses_post($settings['heading']); ?></a></h1>   
                                    <?php endif; ?>
                                    <?php if (( '' !== $settings['button'] ) && ( $settings['show_button'] )) : ?>
                                    <a class="btn" href="<?php echo wp_kses_post($settings['link']); ?>"><span class="btn-text"><?php echo wp_kses_post($settings['button']); ?></span> <span class="btn-border"></span></a>   
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-lg-6">
                        <div class="row no-gutters">
                        	<div class="col-xl-6 col-lg-6">
                        		<?php 
                        		foreach ( $settings['tabs1'] as $item ) : ?>
                        			<div class="gallery-wrapper">
                        				<div class="gallery-img">
                        					<?php if (( '' !== $item['tab_image']['url'] ) && ( $settings['show_image'] )): ?>
                        					<a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""></a>
                        				<?php endif; ?>	
                        				<div class="gallery-video">
                        					<?php if ( '' !== $item['video_link'] ) : ?>
                        						<a class="popup-video" href="<?php echo wp_kses_post($item['video_link']); ?>"><i class="far fa-play"></i></a>
                        					<?php endif; ?>	
                        				</div>
                        			</div>
                        		</div>
                        		<?php
                        	endforeach;
                        	?>
                        </div>
                            <div class="col-xl-6 col-lg-6">
                            	<?php 
                        		foreach ( $settings['tabs2'] as $item ) : ?>
                                <div class="gallery-wrapper">
                        				<div class="gallery-img">
                        					<?php if (( '' !== $item['tab_image']['url'] ) && ( $settings['show_image'] )): ?>
                        					<a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""></a>
                        				<?php endif; ?>	
                        				<div class="gallery-video">
                        					<?php if ( '' !== $item['video_link'] ) : ?>
                        						<a class="popup-video" href="<?php echo wp_kses_post($item['video_link']); ?>"><i class="far fa-play"></i></a>
                        					<?php endif; ?>	
                        				</div>
                        			</div>
                        		</div>
                        		<?php
                        	endforeach;
                        	?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row no-gutters">
                    <div class="col-xl-4 col-lg-4">
                    	<?php 
                    	foreach ( $settings['tabs3'] as $item ) : ?>
                    		<div class="gallery-wrapper">
                    			<div class="gallery-img">
                    				<?php if (( '' !== $item['tab_image']['url'] ) && ( $settings['show_image'] )): ?>
                    				<a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""></a>
                    			<?php endif; ?>	
                    			<div class="gallery-video">
                    				<?php if ( '' !== $item['video_link'] ) : ?>
                    					<a class="popup-video" href="<?php echo wp_kses_post($item['video_link']); ?>"><i class="far fa-play"></i></a>
                    				<?php endif; ?>	
                    			</div>
                    		</div>
                    	</div>
                    	<?php
                    endforeach;
                    ?>
                    </div> 
                    <div class="col-xl-8 col-lg-8">
                    	<?php 
                        		foreach ( $settings['tabs4'] as $item ) : ?>
                        			<div class="gallery-wrapper">
                        				<div class="gallery-img">
                        					<?php if (( '' !== $item['tab_image']['url'] ) && ( $settings['show_image'] )): ?>
                        					<a href="<?php echo wp_kses_post($item['link']); ?>"><img src="<?php echo wp_kses_post($item['tab_image']['url']); ?>" alt=""></a>
                        				<?php endif; ?>	
                        				<div class="gallery-video">
                        					<?php if ( '' !== $item['video_link'] ) : ?>
                        						<a class="popup-video" href="<?php echo wp_kses_post($item['video_link']); ?>"><i class="far fa-play"></i></a>
                        					<?php endif; ?>	
                        				</div>
                        			</div>
                        		</div>
                        <?php
                        	endforeach;
                        	?>
                    </div>
                </div>
            </div>
        <?php elseif( $chose_style == 'gallery_home_2' ): ?>
        	<?php if (( '' !== $settings['image_home_2']['url'] ) && ( $settings['show_image'] )): ?>
        	<div class="gallery-title-area pt-115 pb-410" style="background-image:url(<?php echo wp_kses_post($settings['image_home_2']['url']); ?>)">
        		<?php endif; ?>	
                 <div class="container">
                    <div class="row">
                        <div class="col-xl-8 col-lg-8 offset-lg-2 offset-xl-2">
                            <div class="area-title white-area-title text-center">
                                <span></span>
                                <?php if (( '' !== $settings['heading_home_2'] ) && ( $settings['show_title'] )): ?>
                                <h1><?php echo wp_kses_post($settings['heading_home_2']); ?></h1>
                                <?php endif; ?>	
                                <?php if (( '' !== $settings['sub_heading_home_2'] ) && ( $settings['show_content'] )): ?>
                                <p><?php echo wp_kses_post($settings['sub_heading_home_2']); ?></p>
                                <?php endif; ?>	
                            </div>
                        </div>
                    </div>
                 </div>
             </div>
             <div class="latest-gallery-area pb-100 fix">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8  offset-xl-2">
                            <div class="portfolio-menu text-center mb-55">
                                <button class="active" data-filter="*"><?php echo esc_html__( 'All', 'avitore' ); ?></button>
                                <?php  $categories = get_terms('type1'); 

                                    foreach( (array)$categories as $categorie){

                                    $cat_name = $categorie->name; 

                                    $cat_slug = $categorie->slug;

                                    ?>
                                <button data-filter=".<?php echo $cat_slug ?>" class=""><?php echo $cat_name ?></button>
                            	<?php } ?>
                            </div>
                        </div>
                    </div>
                    <div id="portfolio-grid" class="row row-portfolio">
                        <div class="grid-sizer"></div>
                        <?php 
                        $args = new \WP_Query(array(   
                        	'post_type' => 'gallery', 
                        ));  
                        $i = 1;
                        while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

                    	$cates = get_the_terms(get_the_ID(),'type1');
                                    $cate_name ='';
                                    $cate_slug ='';
                                          foreach((array)$cates as $cate){
                                    if(count($cates)>0){
                                        $cate_name .= $cate->name.' ';
                                        $cate_slug .= $cate->slug.' ';     
                                        } 
                                        } 
                        	$i++;
                        	$gallery_title = get_post_meta(get_the_ID(),'_cmb_gallery_title', true); 
                        	$gallery_subtitle = get_post_meta(get_the_ID(),'_cmb_gallery_subtitle', true); 
                        	?>
                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 grid-item <?php echo $cate_slug ?> mb-30">
                            <div class="portfolio-wrapper">
                                <div class="portfolio-img">
                                    <a href="<?php the_permalink();?>"><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">
                                    </a>
                                    <div class="portfolio-text text-center">
                                        <p><?php echo htmlspecialchars_decode(esc_attr($gallery_subtitle));?></p>
                                        <h2><a href="<?php the_permalink();?>"><?php echo htmlspecialchars_decode(esc_attr($gallery_title));?></a></h2>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        <?php elseif( $chose_style == 'gallery_home_3' ): ?>
        	<div class="gallery-area pt-130 pb-100 fix">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8  offset-xl-2">
                            <div class="portfolio-menu portfolio-2-menu text-center mb-55">
                                <button class="active" data-filter="*"><?php echo esc_html__( 'All', 'avitore' ); ?></button>
                                <?php  $categories = get_terms('type1'); 

                                    foreach( (array)$categories as $categorie){

                                    $cat_name = $categorie->name; 

                                    $cat_slug = $categorie->slug;

                                    ?>
                                <button data-filter=".<?php echo $cat_slug ?>" class=""><?php echo $cat_name ?></button>
                            <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div id="portfolio-grid" class="row row-portfolio">
                        <div class="grid-sizer"></div>
						<?php 
                        $args2 = new \WP_Query(array(   
                        	'post_type' => 'gallery', 
                        ));  
                        $i = 1;
                        while ($wp_query2 -> have_posts()) : $wp_query2 -> the_post(); 

                    	$cates = get_the_terms(get_the_ID(),'type1');
                                    $cate_name ='';
                                    $cate_slug ='';
                                          foreach((array)$cates as $cate){
                                    if(count($cates)>0){
                                        $cate_name .= $cate->name.' ';
                                        $cate_slug .= $cate->slug.' ';     
                                        } 
                                        } 
                        	$i++;
                        	$gallery_title = get_post_meta(get_the_ID(),'_cmb_gallery_title', true); 
                        	$gallery_subtitle = get_post_meta(get_the_ID(),'_cmb_gallery_subtitle', true); 
                        	?>
                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 grid-item <?php echo $cate_slug ?> mb-30">
                            <div class="portfolio-wrapper">
                                <div class="portfolio-img">
                                    <a href="<?php the_permalink();?>"><img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">
                                    </a>
                                    <div class="portfolio-text text-center">
                                        <p><?php echo htmlspecialchars_decode(esc_attr($gallery_subtitle));?></p>
                                        <h2><a href="<?php the_permalink();?>"><?php echo htmlspecialchars_decode(esc_attr($gallery_title));?></a></h2>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>	
	<?php
	}

}