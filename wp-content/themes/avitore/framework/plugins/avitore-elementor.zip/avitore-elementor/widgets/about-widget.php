<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsAbout extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-about';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'about' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_features',
			[
				'label' => esc_html__( 'About', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'about_type_1'  => esc_html__( 'About Type 1', 'bdevs-elementor' ),
					'about_type_2' => esc_html__( 'About Type 2', 'bdevs-elementor' ),
					'about_type_3' => esc_html__( 'About Type 3', 'bdevs-elementor' ),
					'about_type_4' => esc_html__( 'About Type 4', 'bdevs-elementor' ),
					'about_type_5' => esc_html__( 'About Type 5', 'bdevs-elementor' ),
					'about_type_6' => esc_html__( 'About Type 6', 'bdevs-elementor' ),
				],
				'default'   => 'about_type_1',
			]
		);


		$this->add_control(
			'background_image',
			[
				'label'   => esc_html__( 'Background Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Background Image', 'bdevs-elementor' ),
			]
		);	

		$this->add_control(
			'image',
			[
				'label'       => __( 'Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Image', 'bdevs-elementor' ),
			]
		);	

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'post_number',
			[
				'label'     => esc_html__( 'Post Count', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'3'  => esc_html__( '3', 'bdevs-elementor' ),
					'6' => esc_html__( '6', 'bdevs-elementor' ),
					'9' => esc_html__( '9', 'bdevs-elementor' ),
					'12' => esc_html__( '12', 'bdevs-elementor' ),
				],
				'default'   => '3',
			]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'desc',
			]
		);
		
		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'About Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'About One', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'About Two', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Support Content Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'About Three', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
				],
				'fields' => [
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
					],
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_about_2',
			[
				'label' => esc_html__( 'About Type 2', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'background_image_home_2',
			[
				'label'   => esc_html__( 'Background Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Background Image', 'bdevs-elementor' ),
			]
		);		

		$this->add_control(
			'image_home_2',
			[
				'label'   => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your About Image', 'bdevs-elementor' ),
			]
		);	

		

		$this->add_control(
			'title_home_2',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_home_2',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading_home_2',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc_home_2',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs_2',
			[
				'label' => esc_html__( 'About Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'About One', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'About Two', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Support Content Marketing', 'bdevs-elementor' ),
					],
				],
				'fields' => [
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
					],
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_about_3',
			[
				'label' => esc_html__( 'About Type 3', 'bdevs-elementor' ),
			]
		);


		$this->add_control(
			'image_home_3',
			[
				'label'   => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your About Image', 'bdevs-elementor' ),
			]
		);	

		

		$this->add_control(
			'title_home_3',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_home_3',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading_home_3',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc_home_3',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'link_home_3',
			[
				'label'       => __( 'Button Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button link', 'bdevs-elementor' ),
				'default'     => __( 'It is button link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_home_3',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button', 'bdevs-elementor' ),
				'default'     => __( 'It is Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_about_4',
			[
				'label' => esc_html__( 'About Type 4', 'bdevs-elementor' ),
			]
		);


		$this->add_control(
			'image_home_4',
			[
				'label'   => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your About Image', 'bdevs-elementor' ),
			]
		);	

		

		$this->add_control(
			'title_home_4',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_home_4',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading_home_4',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc_home_4',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'link_home_4',
			[
				'label'       => __( 'Button Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button link', 'bdevs-elementor' ),
				'default'     => __( 'It is button link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_home_4',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button', 'bdevs-elementor' ),
				'default'     => __( 'It is Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_about_5',
			[
				'label' => esc_html__( 'About Type 5', 'bdevs-elementor' ),
			]
		);	

		$this->add_control(
			'image_home_6',
			[
				'label'   => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your About Image', 'bdevs-elementor' ),
			]
		);	

		

		$this->add_control(
			'title_home_6',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_home_6',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading_home_6',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc_home_6',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs_5',
			[
				'label' => esc_html__( 'About Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title'   => esc_html__( 'About One', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Focus On Email Marketing', 'bdevs-elementor' ),
					],
					[
						'tab_title'   => esc_html__( 'About Two', 'bdevs-elementor' ),
						'tab_content' => esc_html__( 'Support Content Marketing', 'bdevs-elementor' ),
					],
				],
				'fields' => [
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
					],
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_content_about_6',
			[
				'label' => esc_html__( 'About Type 6', 'bdevs-elementor' ),
			]
		);


		$this->add_control(
			'image_type_6',
			[
				'label'   => esc_html__( 'About Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your About Image', 'bdevs-elementor' ),
			]
		);	

		

		$this->add_control(
			'title_type_6',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your Title', 'bdevs-elementor' ),
				'default'     => __( 'It is Title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);	

		$this->add_control(
			'heading_type_6',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'sub_heading_type_6',
			[
				'label'       => __( 'Sub Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your sub heading', 'bdevs-elementor' ),
				'default'     => __( 'It is sub heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);		

		$this->add_control(
			'desc_type_6',
			[
				'label'       => __( 'Description', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your description', 'bdevs-elementor' ),
				'default'     => __( 'It is content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'link_type_6',
			[
				'label'       => __( 'Button Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button link', 'bdevs-elementor' ),
				'default'     => __( 'It is button link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'button_type_6',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button', 'bdevs-elementor' ),
				'default'     => __( 'It is Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();


		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'center',
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'   => esc_html__( 'Show Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);			

		$this->add_control(
			'show_sub_title',
			[
				'label'   => esc_html__( 'Show Sub Title', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);		

		$this->add_control(
			'show_image',
			[
				'label'   => esc_html__( 'Show Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->add_control(
			'show_content',
			[
				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_button',
			[
				'label'   => esc_html__( 'Show Button', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);


		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		$chose_style = $settings['chose_style'];
		$order = $settings['post_order'];
		$post_number = $settings['post_number'];
		$wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'service',  'orderby' => 'ID', 'order' => $order));
		extract($settings); ?>
		<h2 style="display: none;">1111111111</h2>
		<?php if( $chose_style == 'about_type_1' ): ?>
			
			<?php if (( '' !== $settings['background_image']['url'] ) && ( $settings['show_image'] )): ?>
			<section class="about-section pdt-110 pdb-110 pdb-md-40" data-background="<?php echo wp_kses_post($settings['background_image']['url']); ?>">
			<?php endif; ?>	
				<div class="container">
					<div class="row mrb-80 mrb-lg-70">
						<?php 
							$args = new \WP_Query(array(   
								'post_type' => 'service', 
							));  
							while ($wp_query -> have_posts()) : $wp_query -> the_post(); 

							$service_excerpt = get_post_meta(get_the_ID(),'_cmb_service_excerpt', true);
							$service_icon = get_post_meta(get_the_ID(),'_cmb_service_icon', true);
							?>
						<div class="col-md-6 col-lg-4 col-xl-4">
							<div class="features-item">
								<i class="<?php echo esc_attr($service_icon); ?>"></i>
								<h4 class="feature-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
								<p class="mrb-0"><?php echo esc_attr($service_excerpt);?></p>
							</div>
						</div>
						<?php endwhile; ?>
					</div>
					<div class="row">
						<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['image']['url'] ): ?>
							<div class="about-image">
								<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image']['url']); ?>" alt="">
							</div>
							<?php endif; ?>	
						</div>
						<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['title'] ): ?>
								<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title']); ?></h5>
							<?php endif; ?>	
							<?php if (( '' !== $settings['heading'] ) && ( $settings['show_title'] )): ?>
								<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading']); ?></h2>
							<?php endif; ?>	
							<?php if (( '' !== $settings['sub_heading'] ) && ( $settings['show_content'] )): ?>
								<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading']); ?></p>
							<?php endif; ?>
							<?php if ( '' !== $settings['desc'] ): ?>
								<p class="mrb-50"><?php echo wp_kses_post($settings['desc']); ?></p>
							<?php endif; ?>	
							<div class="row">
								<?php foreach ( $settings['tabs'] as $item ) : ?>
									<div class="col-md-6 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="800ms">
										<div class="about-icon-box mrb-md-70 mrb-md-40">
											<?php if ( '' !== $item['tab_icon'] ): ?>
												<div class="icon">
													<span class="<?php echo wp_kses_post($item['tab_icon']); ?>"></span>
												</div>
											<?php endif; ?>	
											<?php if ( '' !== $item['tab_title'] ): ?>
												<h5 class="title"><?php echo wp_kses_post($item['tab_title']); ?></h5>
											<?php endif; ?>	
										</div>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</section>
		<?php elseif( $chose_style == 'about_type_2' ): ?>
			<?php if (( '' !== $settings['background_image_home_2']['url'] ) && ( $settings['show_image'] )): ?>
			<section class="about-section pdt-110 pdb-110 pdb-md-40" data-background="<?php echo wp_kses_post($settings['background_image_home_2']['url']); ?>">
			<?php endif; ?>	
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['image_home_2']['url'] ): ?>
							<div class="about-image">
								<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image_home_2']['url']); ?>" alt="">
							</div>
							<?php endif; ?>	
						</div>
						<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['title_home_2'] ): ?>
							<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title_home_2']); ?></h5>
							<?php endif; ?>	
							<?php if (( '' !== $settings['heading_home_2'] ) && ( $settings['show_title'] )): ?>
							<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading_home_2']); ?></h2>
							<?php endif; ?>	
							<?php if (( '' !== $settings['sub_heading_home_2'] ) && ( $settings['show_content'] )): ?>
							<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading_home_2']); ?></p>
							<?php endif; ?>	
							<?php if ( '' !== $settings['desc_home_2'] ) : ?>
							<p class="mrb-50"><?php echo wp_kses_post($settings['desc_home_2']); ?></p>
							<?php endif; ?>	
							<div class="row">
								<?php foreach ( $settings['tabs_2'] as $item ) : ?>
								<div class="col-md-6 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="800ms">
									<div class="about-icon-box mrb-md-70 mrb-md-40">
										<?php if ( '' !== $item['tab_icon'] ): ?>
											<div class="icon">
												<span class="<?php echo wp_kses_post($item['tab_icon']); ?>"></span>
											</div>
										<?php endif; ?>	
										<?php if ( '' !== $item['tab_title'] ): ?>
											<h5 class="title"><?php echo wp_kses_post($item['tab_title']); ?></h5>
										<?php endif; ?>	
									</div>
								</div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			</section>
		<?php elseif( $chose_style == 'about_type_3' ): ?>
			<section class="about-section bg-light-pink pdt-110 pdb-110 pdb-md-40">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['image_home_3']['url'] ): ?>
								<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image_home_3']['url']); ?>" alt="">
							<?php endif; ?>	
						</div>
						<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
							<?php if ( '' !== $settings['title_home_3'] ): ?>
								<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title_home_3']); ?></h5>
							<?php endif; ?>	
							<?php if (( '' !== $settings['heading_home_3'] ) && ( $settings['show_title'] )): ?>
								<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading_home_3']); ?></h2>
							<?php endif; ?>	
							<?php if (( '' !== $settings['sub_heading_home_3'] ) && ( $settings['show_content'] )): ?>
								<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading_home_3']); ?></p>
							<?php endif; ?>	
							<?php if ( '' !== $settings['desc_home_3'] ) : ?>
								<p class="mrb-50"><?php echo wp_kses_post($settings['desc_home_3']); ?></p>
							<?php endif; ?>	
							<?php if ( '' !== $settings['button_home_3'] ) : ?>
								<a href="<?php echo wp_kses_post($settings['link_home_3']); ?>" class="cs-btn-one btn-primary-color btn-md"><?php echo wp_kses_post($settings['button_home_3']); ?></a>
							<?php endif; ?>	
					</div>
				</div>
			</div>
		</section>
	<?php elseif( $chose_style == 'about_type_4' ): ?>
		<section class="about-section bg-light-pink pdt-110 pdb-110 pdb-md-40">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
						<?php if ( '' !== $settings['title_home_4'] ): ?>
							<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title_home_4']); ?></h5>
						<?php endif; ?>	
						<?php if (( '' !== $settings['heading_home_4'] ) && ( $settings['show_title'] )): ?>
							<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading_home_4']); ?></h2>
						<?php endif; ?>	
						<?php if (( '' !== $settings['sub_heading_home_4'] ) && ( $settings['show_content'] )): ?>
							<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading_home_4']); ?></p>
						<?php endif; ?>	
						<?php if ( '' !== $settings['desc_home_4'] ) : ?>
							<p class="mrb-50"><?php echo wp_kses_post($settings['desc_home_4']); ?></p>
						<?php endif; ?>	
						<?php if ( '' !== $settings['button_home_4'] ) : ?>
						<a href="<?php echo wp_kses_post($settings['link_home_4']); ?>" class="cs-btn-one btn-primary-color2 btn-md"><?php echo wp_kses_post($settings['button_home_4']); ?></a>
						<?php endif; ?>	
					</div>
					<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
						<?php if ( '' !== $settings['image_home_4']['url'] ): ?>
							<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image_home_4']['url']); ?>" alt="">
						<?php endif; ?>	
					</div>
				</div>
			</div>
		</section>
	<?php elseif( $chose_style == 'about_type_5' ): ?>
		<section class="about-section bg-light-blue pdt-110 pdb-110 pdb-md-40">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
						<?php if ( '' !== $settings['title_home_6'] ): ?>
						<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title_home_6']); ?></h5>
						<?php endif; ?>	
						<?php if (( '' !== $settings['heading_home_6'] ) && ( $settings['show_title'] )): ?>
						<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading_home_6']); ?></h2>
						<?php endif; ?>	
						<?php if (( '' !== $settings['sub_heading_home_6'] ) && ( $settings['show_content'] )): ?>
						<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading_home_6']); ?></p>
						<?php endif; ?>	
						<?php if ( '' !== $settings['desc_home_6'] ) : ?>
						<p class="mrb-50"><?php echo wp_kses_post($settings['desc_home_6']); ?></p>
						<?php endif; ?>	
						<div class="row">
							<?php foreach ( $settings['tabs_5'] as $item ) : ?>
							<div class="col-md-6 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0ms" data-wow-duration="800ms">
								<div class="about-icon-box mrb-md-70 mrb-md-40">
									<?php if ( '' !== $item['tab_icon'] ): ?>
										<div class="icon">
											<span class="<?php echo wp_kses_post($item['tab_icon']); ?>"></span>
										</div>
									<?php endif; ?>	
									<?php if ( '' !== $item['tab_title'] ): ?>
										<h5 class="title"><?php echo wp_kses_post($item['tab_title']); ?></h5>
									<?php endif; ?>	
								</div>
							</div>
							<?php endforeach; ?>
						</div>
					</div>
					<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
						<?php if ( '' !== $settings['image_home_6']['url'] ): ?>
							<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image_home_6']['url']); ?>" alt="">
						<?php endif; ?>	
					</div>
				</div>
			</div>
		</section>
	<?php elseif( $chose_style == 'about_type_6' ): ?>
	<section class="about-section pdt-110 pdb-110 pdb-md-40">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-xl-6 wow fadeInRight" data-wow-delay="0ms" data-wow-duration="1000ms">
					<?php if ( '' !== $settings['title_type_6'] ): ?>
					<h5 class="mrb-15 text-primary-color"><?php echo wp_kses_post($settings['title_type_6']); ?></h5>
					<?php endif; ?>	
					<?php if (( '' !== $settings['heading_type_6'] ) && ( $settings['show_title'] )): ?>
					<h2 class="title-under-line mrb-70"><?php echo wp_kses_post($settings['heading_type_6']); ?></h2>
					<?php endif; ?>	
					<?php if (( '' !== $settings['sub_heading_type_6'] ) && ( $settings['show_content'] )): ?>
					<p class="mrb-25"><?php echo wp_kses_post($settings['sub_heading_type_6']); ?></p>
					<?php endif; ?>	
					<?php if ( '' !== $settings['desc_type_6'] ) : ?>
					<p class="mrb-50"><?php echo wp_kses_post($settings['desc_type_6']); ?></p>
					<?php endif; ?>	
					<?php if ( '' !== $settings['button_type_6'] ) : ?>
					<a href="<?php echo wp_kses_post($settings['link_type_6']); ?>" class="cs-btn-one btn-primary-color2 btn-md"><?php echo wp_kses_post($settings['button_type_6']); ?></a>
					<?php endif; ?>	
				</div>
				<div class="col-md-12 col-xl-6 wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1000ms">
					<?php if (( '' !== $settings['image_type_6']['url'] ) && ( $settings['show_image'] )): ?>
					<img class="image-link mrb-lg-50 mrt-5" src="<?php echo wp_kses_post($settings['image_type_6']['url']); ?>" alt="">
					<?php endif; ?>	
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>	
	<?php
	}

}