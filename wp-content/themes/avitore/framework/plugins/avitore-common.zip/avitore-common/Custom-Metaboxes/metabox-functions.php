<?php

/**

 * Include and setup custom metaboxes and fields.

 *

 * @category YourThemeOrPlugin

 * @package  Metaboxes

 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)

 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress

 */



add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );

/**

 * Define the metabox and field configurations.

 *

 * @param  array $meta_boxes

 * @return array

 */

$textdomain = "avitore";

function cmb_sample_metaboxes( array $meta_boxes ) {



	// Start with an underscore to hide fields from custom fields list

	$prefix = '_cmb_';

	

    $meta_boxes[] = array(

        'id'         => 'page_setting',

        'title'      => 'Page Setting',

        'pages'      => array('page'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

        )

    );



   



    $meta_boxes[] = array(

        'id'         => 'post_setting',

        'title'      => 'Post Setting',

        'pages'      => array('post'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name' => 'Facebook',

                'desc' => 'Input link facebook',

                'default' => '',

                'id' => $prefix . 'single_facebook',

                'type' => 'text'

            ), 

            array(

                'name' => 'Twitter',

                'desc' => 'Input link twitter',

                'default' => '',

                'id' => $prefix . 'single_twitter',

                'type' => 'text'

            ),

            array(

                'name' => 'Linkedin',

                'desc' => 'Input link linkedin',

                'default' => '',

                'id' => $prefix . 'single_linkedin',

                'type' => 'text'

            ),

            array(

                'name' => 'Instagram',

                'desc' => 'Input link instagram',

                'default' => '',

                'id' => $prefix . 'single_instagram',

                'type' => 'text'

            ),

            array(

                'name' => 'Recent Title',

                'desc' => 'Input Recent Title',

                'default' => '',

                'id' => $prefix . 'recent_title',

                'type' => 'text'

            ), 

            array(

                'name' => 'Recent Image',

                'desc' => 'Image Upload',

                'default' => '',

                'id' => $prefix . 'recent_image',

                'type' => 'file'

            ),

            array(

                'name' => 'Home Title',

                'desc' => 'Input Home Title',

                'default' => '',

                'id' => $prefix . 'home_title',

                'type' => 'text'

            ), 

            array(

                'name' => 'Home Image',

                'desc' => 'Image Upload',

                'default' => '',

                'id' => $prefix . 'home_image',

                'type' => 'file'

            ),

        )

    );







    $meta_boxes[] = array(

        'id'         => 'post_setting',

        'title'      => 'Post Setting',

        'pages'      => array('team'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name' => 'Facebook',

                'desc' => 'Input link facebook',

                'default' => '',

                'id' => $prefix . 'team_facebook',

                'type' => 'text'

            ), 

            array(

                'name' => 'Twitter',

                'desc' => 'Input link twitter',

                'default' => '',

                'id' => $prefix . 'team_twitter',

                'type' => 'text'

            ),

            array(

                'name' => 'Instagram',

                'desc' => 'Input link instagram',

                'default' => '',

                'id' => $prefix . 'team_instagram',

                'type' => 'text'

            ),

            array(

                'name' => 'Google Plus',

                'desc' => 'Input link google plus',

                'default' => '',

                'id' => $prefix . 'team_google',

                'type' => 'text'

            ),

            array(

                'name' => 'Job',

                'desc' => 'Input Team Job',

                'default' => '',

                'id' => $prefix . 'team_job',

                'type' => 'text'

            ),

        )

    );







    $meta_boxes[] = array(

        'id'         => 'post_setting',

        'title'      => 'Post Setting',

        'pages'      => array('service'), // Post type

        'context'    => 'normal',

        'priority'   => 'high',

        'show_names' => true, // Show field names on the left

        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox

        'fields' => array(

            array(

                'name' => 'Excerpt',

                'desc' => 'Input Service Excerpt',

                'default' => '',

                'id' => $prefix . 'service_excerpt',

                'type' => 'textarea'

            ), 

            array(

                'name' => 'Service Icon',

                'desc' => 'Service Icon',

                'default' => '',

                'id' => $prefix . 'service_icon',

                'type' => 'text'

            ),

            array(

                'name' => 'Service Image',

                'desc' => 'Service Image',

                'default' => '',

                'id' => $prefix . 'service_image',

                'type' => 'file'

            ),

        )

    );

    

    // Add other metaboxes as needed

    

	return $meta_boxes;

}



add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );

/**

 * Initialize the metabox class.

 */

function cmb_initialize_cmb_meta_boxes() {



	if ( ! class_exists( 'cmb_Meta_Box' ) )

		require_once 'init.php';



} 

