<?php


if (!class_exists("Redux_Framework_sample_config")) {

    class Redux_Framework_sample_config {

        public $args = array();
        public $sections = array();
        public $theme;
        public $ReduxFramework;

        public function __construct() {
            // This is needed. Bah WordPress bugs.  ;)
            if ( defined('TEMPLATEPATH') && strpos( Redux_Helpers::cleanFilePath( __FILE__ ), Redux_Helpers::cleanFilePath( TEMPLATEPATH ) ) !== false) {
                $this->initSettings();
            } else {
                add_action('plugins_loaded', array($this, 'initSettings'), 10);    
            }
        }

        public function initSettings() {

            if ( !class_exists("ReduxFramework" ) ) {
                return;
            }       
            
            // Just for demo purposes. Not needed per say.
            $this->theme = wp_get_theme();

            // Set the default arguments
            $this->setArguments();

            // Set a few help tabs so you can see how it's done
            $this->setHelpTabs();

            // Create the sections and fields
            $this->setSections();

            if (!isset($this->args['opt_name'])) { // No errors please
                return;
            }

            // If Redux is running as a plugin, this will remove the demo notice and links
            //add_action( 'redux/plugin/hooks', array( $this, 'remove_demo' ) );
            // Function to test the compiler hook and demo CSS output.
            //add_filter('redux/options/'.$this->args['opt_name'].'/compiler', array( $this, 'compiler_action' ), 10, 2); 
            // Above 10 is a priority, but 2 in necessary to include the dynamically generated CSS to be sent to the function.
            // Change the arguments after they've been declared, but before the panel is created
            //add_filter('redux/options/'.$this->args['opt_name'].'/args', array( $this, 'change_arguments' ) );
            // Change the default value of a field after it's been set, but before it's been useds
            //add_filter('redux/options/'.$this->args['opt_name'].'/defaults', array( $this,'change_defaults' ) );
            // Dynamically add a section. Can be also used to modify sections/fields
            add_filter('redux/options/' . $this->args['opt_name'] . '/sections', array($this, 'dynamic_section'));

            $this->ReduxFramework = new ReduxFramework($this->sections, $this->args);
        }

        function compiler_action($options, $css) {
            //echo "<h1>The compiler hook has run!";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )

            /*
              // Demo of how to use the dynamic CSS and write your own static CSS file
              $filename = dirname(__FILE__) . '/style' . '.css';
              global $wp_filesystem;
              if( empty( $wp_filesystem ) ) {
              require_once( ABSPATH .'/wp-admin/includes/file.php' );
              WP_Filesystem();
              }

              if( $wp_filesystem ) {
              $wp_filesystem->put_contents(
              $filename,
              $css,
              FS_CHMOD_FILE // predefined mode settings for WP files
              );
              }
             */
        }

        function dynamic_section($sections) {
            //$sections = array();
            $sections[] = array(
                'title' => esc_html__('Section via hook', 'redux-framework-demo'),
                'desc' => esc_html__('<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'redux-framework-demo'),
                'icon' => 'el-icon-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }

        function change_arguments($args) {
            //$args['dev_mode'] = true;

            return $args;
        }


        function change_defaults($defaults) {
            $defaults['str_replace'] = "Testing filter hook!";

            return $defaults;
        }

        // Remove the demo link and the notice of integrated demo from the redux-framework plugin
        function remove_demo() {

            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if (class_exists('ReduxFrameworkPlugin')) {
                remove_filter('plugin_row_meta', array(ReduxFrameworkPlugin::get_instance(), 'plugin_meta_demo_mode_link'), null, 2);
            }

            // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
            remove_action('admin_notices', array(ReduxFrameworkPlugin::get_instance(), 'admin_notices'));
        }

        public function setSections() {

            // Background Patterns Reader
            $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
            $sample_patterns_url = ReduxFramework::$_url . '../sample/patterns/';
            $sample_patterns = array();

            if (is_dir($sample_patterns_path)) :

                if ($sample_patterns_dir = opendir($sample_patterns_path)) :
                    $sample_patterns = array();

                    while (( $sample_patterns_file = readdir($sample_patterns_dir) ) !== false) {

                        if (stristr($sample_patterns_file, '.png') !== false || stristr($sample_patterns_file, '.jpg') !== false) {
                            $name = explode(".", $sample_patterns_file);
                            $name = str_replace('.' . end($name), '', $sample_patterns_file);
                            $sample_patterns[] = array('alt' => $name, 'img' => $sample_patterns_url . $sample_patterns_file);
                        }
                    }
                endif;
            endif;

            ob_start();

            $ct = wp_get_theme();
            $this->theme = $ct;
            $item_name = $this->theme->get('Name');
            $tags = $this->theme->Tags;
            $screenshot = $this->theme->get_screenshot();
            $class = $screenshot ? 'has-screenshot' : '';

            $customize_title = sprintf(__('Customize &#8220;%s&#8221;', 'redux-framework-demo'), $this->theme->display('Name'));
            ?>
            <div id="current-theme" class="<?php echo esc_attr($class); ?>">
            <?php if ($screenshot) : ?>
                <?php if (current_user_can('edit_theme_options')) : ?>
                        <a href="<?php echo wp_customize_url(); ?>" class="load-customize hide-if-no-customize" title="<?php echo esc_attr($customize_title); ?>">
                            <img src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_html_e('Current theme preview', 'pontus'); ?>" />
                        </a>
                <?php endif; ?>
                    <img class="hide-if-customize" src="<?php echo esc_url($screenshot); ?>" alt="<?php esc_html_e('Current theme preview', 'pontus'); ?>" />
            <?php endif; ?>

                <h4>
            <?php echo $this->theme->display('Name'); ?>
                </h4>

                <div>
                    <ul class="theme-info">
                        <li><?php printf(__('By %s', 'redux-framework-demo'), $this->theme->display('Author')); ?></li>
                        <li><?php printf(__('Version %s', 'redux-framework-demo'), $this->theme->display('Version')); ?></li>
                        <li><?php echo '<strong>' . esc_html__('Tags', 'redux-framework-demo') . ':</strong> '; ?><?php printf($this->theme->display('Tags')); ?></li>
                    </ul>
                    <p class="theme-description"><?php echo $this->theme->display('Description'); ?></p>
                <?php
                if ($this->theme->parent()) {
                    printf(' <p class="howto">' . esc_html__('This <a href="%1$s">child theme</a> requires its parent theme, %2$s.', 'pontus') . '</p>', esc_html__('http://codex.wordpress.org/Child_Themes', 'redux-framework-demo'), $this->theme->parent()->display('Name'));
                }
                ?>

                </div>

            </div>

            <?php
            $item_info = ob_get_contents();

            ob_end_clean();

            $sampleHTML = '';
            if (file_exists(dirname(__FILE__) . '/info-html.html')) {
                /** @global WP_Filesystem_Direct $wp_filesystem  */
                global $wp_filesystem;
                if (empty($wp_filesystem)) {
                    require_once(ABSPATH . '/wp-admin/includes/file.php');
                    WP_Filesystem();
                }
                $sampleHTML = $wp_filesystem->get_contents(dirname(__FILE__) . '/info-html.html');
            }
            
            // ACTUAL DECLARATION OF SECTIONS          

            $this->sections[] = array(
                'icon' => 'el-icon-cogs',
                'title' => __('General Settings', 'avitore'),
                'fields' => array(                  
                    array(
                        'id' => 'author_content',
                        'type' => 'textarea',
                        'title' => __('Author content', 'avitore'),
                        'subtitle' => __('Author content', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Vergatheme'
                    ),
                    array(
                        'id' => 'description_content',
                        'type' => 'textarea',
                        'title' => __('Description content', 'avitore'),
                        'subtitle' => __('Description content', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Decent Material CV'
                    ),
                    array(
                        'id' => 'keywords_content',
                        'type' => 'textarea',
                        'title' => __('SEO Description', 'avitore'),
                        'subtitle' => __('SEO Description', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ' '
                    ),
                    array(
                        'id' => 'viewport_content',
                        'type' => 'textarea',
                        'title' => __('Viewport content', 'avitore'),
                        'subtitle' => __('Viewport content', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'width=device-width, initial-scale=1'
                    ),
                    array(
                        'id' => 'seo_des',
                        'type' => 'textarea',
                        'title' => __('SEO Description', 'avitore'),
                        'subtitle' => __('SEO Description', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'seo_key',
                        'type' => 'textarea',
                        'title' => __('SEO Keywords', 'avitore'),
                        'subtitle' => __('SEO Keywords', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ), 
                )
            );
            
            $this->sections[] = array(
                'icon' => ' el-icon-picture',
                'title' => __('Logo & Favicon Settings', 'avitore'),
                'fields' => array(       
                    array(
                        'id' => 'logo',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Logo Upload', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your logo.', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'text_logo',
                        'type' => 'text',
                        'title' => __('Text Logo', 'avitore'),
                        'subtitle' => __('Input Text Logo', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'avitore'
                    ),
                    array(
                        'id' => 'favicon',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Favicon Upload', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Favicon.', 'avitore'),
                        'default' => ''
                    ),
                )
            );



            $this->sections[] = array(
                'icon' => 'el-icon-list',
                'title' => __('Blog Settings', 'avitore'),
                'fields' => array(
                    array(
                        'id' => 'blog_image',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Blog Image', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Image Background', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'blog_title',
                        'type' => 'text',
                        'title' => __('Blog title', 'avitore'),
                        'subtitle' => __('Input Blog title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Blog Title'
                    ),
                    array(
                        'id' => 'blog_subtitle',
                        'type' => 'textarea',
                        'title' => __('Blog Subtitle', 'avitore'),
                        'subtitle' => __('Input Blog Subtitle', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Blog Subtitle'
                    ),
                    array(
                        'id' => 'blog_details_title',
                        'type' => 'text',
                        'title' => __('Blog Details title', 'avitore'),
                        'subtitle' => __('Input Blog Details title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Blog Details Title'
                    ),
                    array(
                        'id' => 'blog_details_subtitle',
                        'type' => 'textarea',
                        'title' => __('Blog Details subtitle', 'avitore'),
                        'subtitle' => __('Input Blog Details subtitle', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Blog subtitle'
                    ),
                    array(
                        'id' => 'blog_by',
                        'type' => 'text',
                        'title' => __('Text By', 'avitore'),
                        'subtitle' => __('Input Text By', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'By'
                    ), 
                    array(
                        'id' => 'blog_on',
                        'type' => 'text',
                        'title' => __('Text On', 'avitore'),
                        'subtitle' => __('Input Text On', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'On'
                    ), 
                    array(
                        'id' => 'blog_in',
                        'type' => 'text',
                        'title' => __('Text In', 'avitore'),
                        'subtitle' => __('Input Text In', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'In'
                    ), 
                    array(
                        'id' => 'blog_excerpt',
                        'type' => 'text',
                        'title' => __('Blog custom excerpt leng', 'avitore'),
                        'subtitle' => __('Input Blog custom excerpt leng', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '50'
                    ),
                    array(
                        'id' => 'read_more',
                        'type' => 'text',
                        'title' => __('Button Text For Post', 'avitore'),
                        'subtitle' => __('Input Button Text', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Read More'
                    ),
                 )
            ); 


            $this->sections[] = array(
                'icon' => ' el-icon-picture',
                'title' => __('Page Settings', 'avitore'),
                'fields' => array(    
                    array(
                        'id' => 'project_details_title',
                        'type' => 'text',
                        'title' => __('Project Details title', 'avitore'),
                        'subtitle' => __('Input Project Details title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Project Details'
                    ),
                    array(
                        'id' => 'team_details_title',
                        'type' => 'text',
                        'title' => __('Team Details title', 'avitore'),
                        'subtitle' => __('Input Team Details title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Team Details'
                    ),
                    array(
                        'id' => 'client_image_1',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 1', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'client_image_2',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 2', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'client_image_3',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 3', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'client_image_4',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 4', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'client_image_5',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 5', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'client_image_6',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Client Image 6', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Client Image', 'avitore'),
                        'default' => ''
                    ),
                )
            );


            $this->sections[] = array(
                'icon' => 'el-icon-graph',
                'title' => __('404 Settings', 'avitore'),
                'fields' => array(
                    array(
                        'id' => '404_image',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('404 Image', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Image Background', 'avitore'),
                        'default' => ''
                    ),
                     array(
                        'id' => '404_title',
                        'type' => 'text',
                        'title' => __('404 Title', 'avitore'),
                        'subtitle' => __('Input 404 Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '404 Error'
                    ),  
                    array(
                        'id' => '404_subtitle',
                        'type' => 'textarea',
                        'title' => __('404 subtitle', 'avitore'),
                        'subtitle' => __('Input 404 subtitle', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Page Not Found..'
                    ), 
                    array(
                        'id' => '404_desc',
                        'type' => 'textarea',
                        'title' => __('404 description', 'avitore'),
                        'subtitle' => __('Input 404 description', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repudiandae odit iste exerc ssumenda voluptas quidem sit maiores odio velit voluptate.'
                    ), 
                    array(
                        'id' => '404_text',
                        'type' => 'text',
                        'title' => __('404 Text Button', 'avitore'),
                        'subtitle' => __('Input 404 Button', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'Back To Home page'
                    ), 
                               
                 )
            );

            $this->sections[] = array(
                'icon' => ' el-icon-credit-card',
                'title' => __('Header Settings', 'avitore'),
                'fields' => array(  
                    array(
                        'id' => 'header_logo',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Logo', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Logo Image on Page Default.', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_logo_2',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Logo 2', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Logo Image 2 on Page Default.', 'avitore'),
                        'default' => ''
                    ),
                    
                    array(
                        'id' => 'header_link_facebook',
                        'type' => 'text',
                        'title' => __('Link Facebook', 'avitore'),
                        'subtitle' => __('Input Link Facebook', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '#'
                    ),
                    array(
                        'id' => 'header_link_twitter',
                        'type' => 'text',
                        'title' => __('Link Twitter', 'avitore'),
                        'subtitle' => __('Input Link Twitter', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '#'
                    ),
                    array(
                        'id' => 'header_link_linkedin',
                        'type' => 'text',
                        'title' => __('Link Linkedin', 'avitore'),
                        'subtitle' => __('Input Link Linkedin', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '#'
                    ), 
                    array(
                        'id' => 'header_link_google',
                        'type' => 'text',
                        'title' => __('Link Google', 'avitore'),
                        'subtitle' => __('Input Link Google', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '#'
                    ),
                    array(
                        'id' => 'header_link_instagram',
                        'type' => 'text',
                        'title' => __('Link Instagram', 'avitore'),
                        'subtitle' => __('Input Link Instagram', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => '#'
                    ),
                    array(
                        'id' => 'header_lang_1',
                        'type' => 'text',
                        'title' => __('Header Language 1', 'avitore'),
                        'subtitle' => __('Input Header Language 1', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_lang_2',
                        'type' => 'text',
                        'title' => __('Header Language 2', 'avitore'),
                        'subtitle' => __('Input Header Language 2', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_lang_3',
                        'type' => 'text',
                        'title' => __('Header Language 3', 'avitore'),
                        'subtitle' => __('Input Header Language 3', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_lang_4',
                        'type' => 'text',
                        'title' => __('Header Language 4', 'avitore'),
                        'subtitle' => __('Input Header Language 4', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_lang_5',
                        'type' => 'text',
                        'title' => __('Header Language 5', 'avitore'),
                        'subtitle' => __('Input Header Language 5', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'link_lang_1',
                        'type' => 'text',
                        'title' => __('link Language 1', 'avitore'),
                        'subtitle' => __('Input link Language 1', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'link_lang_2',
                        'type' => 'text',
                        'title' => __('link Language 2', 'avitore'),
                        'subtitle' => __('Input link Language 2', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'link_lang_3',
                        'type' => 'text',
                        'title' => __('link Language 3', 'avitore'),
                        'subtitle' => __('Input link Language 3', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'link_lang_4',
                        'type' => 'text',
                        'title' => __('link Language 4', 'avitore'),
                        'subtitle' => __('Input link Language 4', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'link_lang_5',
                        'type' => 'text',
                        'title' => __('link Language 5', 'avitore'),
                        'subtitle' => __('Input link Language 5', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_address',
                        'type' => 'text',
                        'title' => __('Header Address', 'avitore'),
                        'subtitle' => __('Input Header Address', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_email',
                        'type' => 'text',
                        'title' => __('Header Email', 'avitore'),
                        'subtitle' => __('Input Header Email', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_email_title',
                        'type' => 'text',
                        'title' => __('Header Email Title', 'avitore'),
                        'subtitle' => __('Input Header Email Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_email_subtitle',
                        'type' => 'text',
                        'title' => __('Header Email Subtitle', 'avitore'),
                        'subtitle' => __('Input Header Email Subtitle', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_email_link',
                        'type' => 'text',
                        'title' => __('Header Email Link', 'avitore'),
                        'subtitle' => __('Input Header Email Link', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_phone_title',
                        'type' => 'text',
                        'title' => __('Header Phone Title', 'avitore'),
                        'subtitle' => __('Input Header Phone Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_phone_subtitle',
                        'type' => 'text',
                        'title' => __('Header Phone Subtitle', 'avitore'),
                        'subtitle' => __('Input Header Phone Subtitle', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_phone_link',
                        'type' => 'text',
                        'title' => __('Header Phone Subtitle 2', 'avitore'),
                        'subtitle' => __('Input Header Phone Subtitle 2', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_button',
                        'type' => 'text',
                        'title' => __('Header Button', 'avitore'),
                        'subtitle' => __('Input Header Button', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_button_link',
                        'type' => 'text',
                        'title' => __('Header Button Link', 'avitore'),
                        'subtitle' => __('Input Header Button Link', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_title',
                        'type' => 'text',
                        'title' => __('Side Panel Title', 'avitore'),
                        'subtitle' => __('Input Side Panel Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_title_2',
                        'type' => 'text',
                        'title' => __('Side Panel Title 2', 'avitore'),
                        'subtitle' => __('Input Side Panel Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_title_3',
                        'type' => 'text',
                        'title' => __('Side Panel Title 3', 'avitore'),
                        'subtitle' => __('Input Side Panel Title', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_address',
                        'type' => 'text',
                        'title' => __('Side Panel Address', 'avitore'),
                        'subtitle' => __('Input Side Panel Address', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_email',
                        'type' => 'text',
                        'title' => __('Side Panel Email', 'avitore'),
                        'subtitle' => __('Input Side Panel Email', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'side_panel_phone',
                        'type' => 'text',
                        'title' => __('Side Panel Phone', 'avitore'),
                        'subtitle' => __('Input Side Panel Phone', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_1',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 1', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 1', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_2',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 2', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 2', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_3',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 3', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 3', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_4',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 4', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 4', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_5',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 5', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 5', 'avitore'),
                        'default' => ''
                    ),
                    array(
                        'id' => 'header_image_6',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Header Image 6', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your header Image 6', 'avitore'),
                        'default' => ''
                    ),
                )
            );

            
            $this->sections[] = array(
                'icon' => ' el-icon-credit-card',
                'title' => __('Footer Settings', 'avitore'),
                'fields' => array( 
                    array(
                        'id' => 'footer_desc',
                        'type' => 'text',
                        'title' => __('Footer Description', 'avitore'),
                        'subtitle' => __('Footer Description', 'avitore'),
                        'default' => 'Subscribe to our email newsletter to get update, discount and special offers.',
                    ),
                    array(
                        'id' => 'footer_image',
                        'type' => 'media',
                        'url' => true,
                        'title' => __('Footer Image', 'avitore'),
                        'compiler' => 'true',
                        //'mode' => false, // Can be set to false to allow any media type, or can also be set to any mime type.
                        'desc' => __('', 'avitore'),
                        'subtitle' => __('Upload your Footer Image', 'avitore'),
                        'default' => ''
                    ),  
                    array(
                        'id' => 'footer_text',
                        'type' => 'text',
                        'title' => __('Footer Text', 'avitore'),
                        'subtitle' => __('Copyright Text', 'avitore'),
                        'default' => 'COPYRIGHT  2019.BDEVS. ALL RIGHTS RESERVED',
                    ),
                    array(
                        'id' => 'footer_text_2',
                        'type' => 'text',
                        'title' => __('Footer Text 2', 'avitore'),
                        'subtitle' => __('Footer Text 2', 'avitore'),
                        'default' => 'Purchase our Template',
                    ),
                    array(
                        'id' => 'footer_link',
                        'type' => 'text',
                        'title' => __('Footer Link', 'avitore'),
                        'subtitle' => __('Footer Link', 'avitore'),
                        'default' => '#',
                    ),
                )
            );
            
            $this->sections[] = array(
                'icon' => 'el-icon-graph',
                'title' => __('Form Settings', 'avitore'),
                'fields' => array(
                     array(
                        'id' => 'form_email',
                        'type' => 'text',
                        'title' => __('Form email', 'avitore'),
                        'subtitle' => __('Form email', 'avitore'),
                        'desc' => __('', 'avitore'),
                        'default' => 'info@domain.com'
                    ),                 
                 )
            );
            $this->sections[] = array(
                'icon' => 'el-icon-website',
                'title' => __('Styling Options', 'avitore'),
                'fields' => array(
                    array(
                        'id' => 'chosen-color',
                        'type' => 'checkbox',
                        'title' => __('Enable edit color', 'avitore'),
                        'subtitle' => '',
                        'desc' => '',
                        'default' => '0'// 1 = on | 0 = off
                    ),
                    array(
                        'id' => 'main-color-1',
                        'type' => 'color',
                        'title' => __('Theme Main Color 1', 'avitore'),
                        'subtitle' => __('Pick the main color for the theme (default: #ffe79b).', 'avitore'),
                        'default' => '#2c3e50',
                        'validate' => 'color',
                    ),
                    array(
                        'id' => 'body-font2',
                        'type' => 'typography',
                        'output' => array('body'),
                        'title' => __('Body Font', 'avitore'),
                        'subtitle' => __('Specify the body font properties.', 'avitore'),
                        'google' => true,
                        'default' => array(
                            'color' => '#333',
                        ),
                    ),
                     array(
                        'id' => 'custom-css',
                        'type' => 'ace_editor',
                        'title' => __('CSS Code', 'avitore'),
                        'subtitle' => __('Paste your CSS code here.', 'avitore'),
                        'mode' => 'css',
                        'theme' => 'monokai',
                        'desc' => 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.',
                        'default' => "#header{\nmargin: 0 auto;\n}"
                    ),
                )
            );

        }

        public function setHelpTabs() {

            // Custom page help tabs, displayed using the help API. Tabs are shown in order of definition.
            $this->args['help_tabs'][] = array(
                'id' => 'redux-opts-1',
                'title' => esc_html__('Theme Information 1', 'pontus'),
                'content' => esc_html__('<p>This is the tab content, HTML is allowed.</p>', 'pontus')
            );

            $this->args['help_tabs'][] = array(
                'id' => 'redux-opts-2',
                'title' => esc_html__('Theme Information 2', 'pontus'),
                'content' => esc_html__('<p>This is the tab content, HTML is allowed.</p>', 'pontus')
            );

            // Set the help sidebar
            $this->args['help_sidebar'] = esc_html__('<p>This is the sidebar content, HTML is allowed.</p>', 'pontus');
        }

        public function setArguments() {

            $theme = wp_get_theme(); // For use with some settings. Not necessary.

            $this->args = array(
                // TYPICAL -> Change these values as you need/desire
                'opt_name' => 'redux_demo', // This is where your data is stored in the database and also becomes your global variable name.
                'display_name' => $theme->get('Name'), // Name that appears at the top of your panel
                'display_version' => $theme->get('Version'), // Version that appears at the top of your panel
                'menu_type' => 'menu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
                'allow_sub_menu' => true, // Show the sections below the admin menu item or not
                'menu_title' => esc_html__('avitore Options', 'pontus'),
                'page' => esc_html__('avitore Options', 'pontus'),
                // You will need to generate a Google API key to use this feature.
                // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
                'google_api_key' => 'AIzaSyBM9vxebWLN3bq4Urobnr6tEtn7zM06rEw', // Must be defined to add google fonts to the typography module
                //'admin_bar' => false, // Show the panel pages on the admin bar
                'global_variable' => '', // Set a different name for your global variable other than the opt_name
                'dev_mode' => true, // Show the time the page took to load, etc
                'customizer' => true, // Enable basic customizer support
                // OPTIONAL -> Give you extra features
                'page_priority' => null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
                'page_parent' => 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
                'page_permissions' => 'manage_options', // Permissions needed to access the options panel.
                'menu_icon' => '', // Specify a custom URL to an icon
                'last_tab' => '', // Force your panel to always open to a specific tab (by id)
                'page_icon' => 'icon-themes', // Icon displayed in the admin panel next to your menu_title
                'page_slug' => '_options', // Page slug used to denote the panel
                'save_defaults' => true, // On load save the defaults to DB before user clicks save or not
                'default_show' => false, // If true, shows the default value next to each field that is not the default value.
                'default_mark' => '', // What to print by the field's title if the value shown is default. Suggested: *
                // CAREFUL -> These options are for advanced use only
                'transient_time' => 60 * MINUTE_IN_SECONDS,
                'output' => true, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
                'output_tag' => true, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
                //'domain'              => 'redux-framework', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
                //'footer_credit'       => '', // Disable the footer credit of Redux. Please leave if you can help it.
                // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
                'database' => '', // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
                'show_import_export' => true, // REMOVE
                'system_info' => false, // REMOVE
                'help_tabs' => array(),
                'help_sidebar' => '', // esc_html__( '', $this->args['domain'] );            
            );


            // SOCIAL ICONS -> Setup custom links in the footer for quick links in your panel footer icons.     
            $this->args['share_icons'][] = array(
                'url' => 'https://github.com/ReduxFramework/ReduxFramework',
                'title' => 'Visit us on GitHub',
                'icon' => 'el-icon-github'
                    // 'img' => '', // You can use icon OR img. IMG needs to be a full URL.
            );
            $this->args['share_icons'][] = array(
                'url' => 'https://www.facebook.com/pages/Redux-Framework/243141545850368',
                'title' => 'Like us on Facebook',
                'icon' => 'el-icon-facebook'
            );
            $this->args['share_icons'][] = array(
                'url' => 'http://twitter.com/reduxframework',
                'title' => 'Follow us on Twitter',
                'icon' => 'el-icon-twitter'
            );
            $this->args['share_icons'][] = array(
                'url' => 'http://www.linkedin.com/company/redux-framework',
                'title' => 'Find us on LinkedIn',
                'icon' => 'el-icon-linkedin'
            );



            // Panel Intro text -> before the form
            if (!isset($this->args['global_variable']) || $this->args['global_variable'] !== false) {
                if (!empty($this->args['global_variable'])) {
                    $v = $this->args['global_variable'];
                } else {
                    $v = str_replace("-", "_", $this->args['opt_name']);
                }
                $this->args['intro_text'] = sprintf(__('<p>Did you know that Redux sets a global variable for you? To access any of your saved options from within your code you can use your global variable: <strong>$%1$s</strong></p>', 'pontus'), $v);
            } else {
                $this->args['intro_text'] = esc_html__('<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'pontus');
            }

            // Add content after the form.
            $this->args['footer_text'] = esc_html__('<p>This text is displayed below the options panel. It isn\'t required, but more info is always better! The footer_text field accepts all HTML.</p>', 'pontus');
        }

    }

    new Redux_Framework_sample_config();
}


if (!function_exists('redux_my_custom_field')):

    function redux_my_custom_field($field, $value) {
        print_r($field);
        print_r($value);
    }

endif;

if (!function_exists('redux_validate_callback_function')):

    function redux_validate_callback_function($field, $value, $existing_value) {
        $error = false;
        $value = 'just testing';
        /*
          do your validation

          if(something) {
          $value = $value;
          } elseif(something else) {
          $error = true;
          $value = $existing_value;
          $field['msg'] = 'your custom error message';
          }
         */

        $return['value'] = $value;
        if ($error == true) {
            $return['error'] = $field;
        }
        return $return;
    }


endif;