<?php
// register post type Portfolio

add_action( 'init', 'register_avitore_Case' );
function register_avitore_Case() {
    
    $labels = array( 
        'name' => __( 'Case', 'avitore' ),
        'singular_name' => __( 'Case', 'avitore' ),
        'add_new' => __( 'Add New Case', 'avitore' ),
        'add_new_item' => __( 'Add New Case', 'avitore' ),
        'edit_item' => __( 'Edit Case', 'avitore' ),
        'new_item' => __( 'New Case', 'avitore' ),
        'view_item' => __( 'View Case', 'avitore' ),
        'search_items' => __( 'Search Case', 'avitore' ),
        'not_found' => __( 'No Case found', 'avitore' ),
        'not_found_in_trash' => __( 'No Case found in Trash', 'avitore' ),
        'parent_item_colon' => __( 'Parent Case:', 'avitore' ),
        'menu_name' => __( 'Case', 'avitore' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Case',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Case', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon'     => 'dashicons-editor-paste-text',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Case', $args );
}
add_action( 'init', 'create_CaseType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_CaseType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'avitore' ),
    'singular_name' => __( 'Type', 'avitore' ),
    'search_items' =>  __( 'Search Type','avitore' ),
    'all_items' => __( 'All Type','avitore' ),
    'parent_item' => __( 'Parent Type','avitore' ),
    'parent_item_colon' => __( 'Parent Type:','avitore' ),
    'edit_item' => __( 'Edit Type','avitore' ), 
    'update_item' => __( 'Update Type','avitore' ),
    'add_new_item' => __( 'Add New Type','avitore' ),
    'new_item_name' => __( 'New Type Name','avitore' ),
    'menu_name' => __( 'Type','avitore' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Case',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}


add_action( 'init', 'register_avitore_Team' );
function register_avitore_Team() {
    
    $labels = array( 
        'name' => __( 'Team', 'avitore' ),
        'singular_name' => __( 'Team', 'avitore' ),
        'add_new' => __( 'Add New Team', 'avitore' ),
        'add_new_item' => __( 'Add New Team', 'avitore' ),
        'edit_item' => __( 'Edit Team', 'avitore' ),
        'new_item' => __( 'New Team', 'avitore' ),
        'view_item' => __( 'View Team', 'avitore' ),
        'search_items' => __( 'Search Team', 'avitore' ),
        'not_found' => __( 'No Team found', 'avitore' ),
        'not_found_in_trash' => __( 'No Team found in Trash', 'avitore' ),
        'parent_item_colon' => __( 'Parent Team:', 'avitore' ),
        'menu_name' => __( 'Team', 'avitore' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Team',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Team', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-groups', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Team', $args );
}
add_action( 'init', 'create_TeamType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_TeamType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'avitore' ),
    'singular_name' => __( 'Type', 'avitore' ),
    'search_items' =>  __( 'Search Type','avitore' ),
    'all_items' => __( 'All Type','avitore' ),
    'parent_item' => __( 'Parent Type','avitore' ),
    'parent_item_colon' => __( 'Parent Type:','avitore' ),
    'edit_item' => __( 'Edit Type','avitore' ), 
    'update_item' => __( 'Update Type','avitore' ),
    'add_new_item' => __( 'Add New Type','avitore' ),
    'new_item_name' => __( 'New Type Name','avitore' ),
    'menu_name' => __( 'Type','avitore' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Team',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));


}


add_action( 'init', 'register_avitore_Service' );
function register_avitore_Service() {
    
    $labels = array( 
        'name' => __( 'Service', 'avitore' ),
        'singular_name' => __( 'Service', 'avitore' ),
        'add_new' => __( 'Add New Service', 'avitore' ),
        'add_new_item' => __( 'Add New Service', 'avitore' ),
        'edit_item' => __( 'Edit Service', 'avitore' ),
        'new_item' => __( 'New Service', 'avitore' ),
        'view_item' => __( 'View Service', 'avitore' ),
        'search_items' => __( 'Search Service', 'avitore' ),
        'not_found' => __( 'No Service found', 'avitore' ),
        'not_found_in_trash' => __( 'No Service found in Trash', 'avitore' ),
        'parent_item_colon' => __( 'Parent Service:', 'avitore' ),
        'menu_name' => __( 'Service', 'avitore' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Service',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Service', 'type2' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-hammer', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Service', $args );
}
add_action( 'init', 'create_ServiceType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_ServiceType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'avitore' ),
    'singular_name' => __( 'Type', 'avitore' ),
    'search_items' =>  __( 'Search Type','avitore' ),
    'all_items' => __( 'All Type','avitore' ),
    'parent_item' => __( 'Parent Type','avitore' ),
    'parent_item_colon' => __( 'Parent Type:','avitore' ),
    'edit_item' => __( 'Edit Type','avitore' ), 
    'update_item' => __( 'Update Type','avitore' ),
    'add_new_item' => __( 'Add New Type','avitore' ),
    'new_item_name' => __( 'New Type Name','avitore' ),
    'menu_name' => __( 'Type','avitore' ),
  );     

// Now register the taxonomy

  register_taxonomy('type2',array('Service',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type2' ),
  ));


}